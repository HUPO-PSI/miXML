package mint.psi.filemakers.xsd;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.ToolTipManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

import org.exolab.castor.xml.schema.Annotated;
import org.exolab.castor.xml.schema.Annotation;
import org.exolab.castor.xml.schema.AttributeDecl;
import org.exolab.castor.xml.schema.ComplexType;
import org.exolab.castor.xml.schema.Documentation;
import org.exolab.castor.xml.schema.ElementDecl;
import org.exolab.castor.xml.schema.Group;
import org.exolab.castor.xml.schema.Order;
import org.exolab.castor.xml.schema.Particle;
import org.exolab.castor.xml.schema.Schema;
import org.exolab.castor.xml.schema.Structure;
import org.exolab.castor.xml.schema.XMLType;
import org.exolab.castor.xml.schema.reader.SchemaReader;
import org.xml.sax.InputSource;

/**
 * This Class creates and manages a Panel for a tree representation
 * of a XML schema
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 * 
 */
public abstract class AbstractXsdTree extends JPanel {

	/*	DefaultTreeSelectionModel tree */
	protected JTree tree;

	/* the root node of the tree */
	protected XslNode rootNode;

	protected DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);

	/**
	 *  if this variable is setted to true (by the constructor)
	 * while expanding a node, the tree will automaticaly 
	 * create the minimum amount of nodes required 
	 * according by the schema
	 */
	private final boolean autoDuplicate;

	/**
	 *  if this variable is setted to true (by the constructor)
	 * while expanding a node that discribe a choice, the tree will 
	 * give to the user the possibility to choose what element to expand.
	 * Else all possibility is displayed 
	 */
	private final boolean manageChoices;

	private JScrollPane scrollPane;

	/** dimension for buttons */
	protected final Dimension buttonsDimension = new Dimension(200, 25);

	/** the schema */
	protected Schema schema;

	/**
	 * Returns an instance of <code>AbstractXslTree</code> 
	 *
	 * @param autoduplicate  indicates that new nodes will be automaticly 
	 * created according to the minimum defined in the schema (minOccurs) 
	 */
	public AbstractXsdTree(boolean autoduplicate, boolean manageChoices) {
		super(new BorderLayout());

		this.autoDuplicate = autoduplicate;
		this.manageChoices = manageChoices;

		tree = new JTree(treeModel);
		scrollPane = new JScrollPane(tree);

		add(scrollPane, BorderLayout.CENTER);
		add(getButtonPanel(), BorderLayout.EAST);
	}

	/**
	 *  create a panel for buttons: 
	 *  her have to be added every buttons such as
	 * the ones that allows to load a schema 
	 */
	protected abstract Box getButtonPanel();

	/**
	 * the xsl file describing the schema
	 */
	protected File schemaFile;

	/**
	 * open a file chooser allowing to choose 
	 * the file containing the schema, read it, create the tree,
	 * and finaly reinitialize everything using a previous tree.
	 * Those reinitialisations have to be defined in the 
	 * <code>emptySelectionLists</code> method
	 */
	protected void loadSchema() {
		try {
			JFileChooser fileChooser = new JFileChooser(".");
			int returnVal = fileChooser.showOpenDialog(this);
			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			FileReader xsd = new FileReader(fileChooser.getSelectedFile());
			SchemaReader reader = new SchemaReader(new InputSource(xsd));
			schema = reader.read();
			schemaFile = fileChooser.getSelectedFile();
			createTree();
			emptySelectionLists();
		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers]",
				JOptionPane.ERROR_MESSAGE);
		} catch (IOException ioe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers]",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException ne) {
			return;
		}
	}

	/**
	 * this method should reinitialize every variable makin reference 
	 * to the actual tree, such as any <code>List</code> used to
	 * make associations to externals objects. 
	 */
	protected abstract void emptySelectionLists();

	/**
	 * when a node is clicked by the mouse, deploy it
	 * using th <code>extendPath</code> method
	 */
	class XslTreeSelectionListener implements TreeSelectionListener {
		public void valueChanged(TreeSelectionEvent e) {
			XslNode node = (XslNode) tree.getLastSelectedPathComponent();
			if (node == null)
				return;

			if (node.isExtended)
				return;
			extendPath(node);
		}
	}

	/**
	 * create the tree according to the schema loaded.
	 * The root node is displayed
	 *
	 */
	private void createTree() {
		Enumeration elts = schema.getElementDecls();
		ElementDecl elt = (ElementDecl) elts.nextElement();

		XslNode node = new XslNode(elt);

		/* rootNode is mandatory */
		rootNode = node;
		rootNode.use();

		treeModel = new DefaultTreeModel(rootNode);
		tree.setModel(treeModel);
		ToolTipManager.sharedInstance().registerComponent(tree);
		setCellRenderer();
		tree.addTreeSelectionListener(new XslTreeSelectionListener());
		tree.setShowsRootHandles(true);
	}

	/**
	 * the cell renderer used by the constructor
	 *
	 */
	protected abstract void setCellRenderer();

	/**
	 *  get the number of children with given name for a node
	 * used for example to know if the maximum number of node of that 
	 * type is already reach or to create the minimum number of node of 
	 * that type requiered according to the schema 
	 */
	private int getChildrenCount(XslNode node, String childrenName) {
		int count = 0;
		Enumeration childrens = node.children();
		while (childrens.hasMoreElements()) {
			if (((XslNode) childrens.nextElement()).toString() == childrenName)
				count++;
		}
		return count;
	}

	/**
	 *  an enumeration of all children
	 *  add recursively to this enumeration 
	 *  the childrens of childrens if child is a choice
	 * @result a list of <code>String</code> 
	 */
	private ArrayList getChoices(Group g) {
		ArrayList choices = new ArrayList();

		Enumeration childrens = g.enumerate();

		while (childrens.hasMoreElements()) {
			Annotated child = (Annotated) childrens.nextElement();
			choices.add(child);
		}
		return choices;
	}

	/**
	 *  check elements and attributes for the structure contained in this node
	 * create nodes 
	 * and add'em to the tree
	 */
	private void extendPath(XslNode node) {
		Annotated annotated = (Annotated) (node.getUserObject());

		switch (annotated.getStructureType()) {
			case Structure.ATTRIBUTE :
				break;

			case Structure.GROUP :
				/* if it's a complex type, look inside */
				Group g = (Group) annotated;

				XslNode parent = (XslNode) node.getParent();

				/* position is important when adding new node */
				int position = parent.getIndex(node);

				/*
				 * if a sequence: add all childs
				* if a choice, ask user
				*/
				if (g.getOrder().getType() == Order.CHOICE && manageChoices) {
					ArrayList choices = getChoices(g);

					ArrayList possibilities = new ArrayList();

					for (int i = 0; i < choices.size(); i++) {
						try {
							possibilities.add(
								((ElementDecl) choices.get(i)).getName());
						} catch (ClassCastException e) {
							/* a group: give an overview */
							possibilities.add(
								choiceToString((Group) choices.get(i)));
						}
					}

					String choice =
						(String) JOptionPane.showInputDialog(
							new JFrame(),
							"what type of element do you want to add?",
							"[PSI makers] choice",
							JOptionPane.QUESTION_MESSAGE,
							new ImageIcon("images/ic-att.gif"),
							possibilities.toArray(),
							"");

					if ((choice == null) || (choice.length() == 0))
						return;

					((XslNode) node.getParent()).remove(parent.getIndex(node));

					XslNode newNode;

					newNode =
						new XslNode(
							(Annotated) choices.get(
								possibilities.indexOf(choice)));
					newNode.isRequired = node.isRequired;
					newNode.min = node.min;
					newNode.max = node.max;
					newNode.originalParent = node;
					parent.insert(newNode, position);

					if (((Annotated) newNode.getUserObject())
						.getStructureType()
						!= Structure.GROUP)
						extendPath(newNode);
					else if (
						((Group) newNode.getUserObject()).getOrder().getType()
							!= Order.CHOICE)
						extendPath(newNode);

				} else { /* sequence */
					((XslNode) node.getParent()).remove(parent.getIndex(node));

					Enumeration elts = g.enumerate();
					while (elts.hasMoreElements()) {

						Annotated element = (Annotated) elts.nextElement();

						XslNode newNode = new XslNode(element);
						parent.add(newNode);

						if (((Annotated) newNode.getUserObject())
							.getStructureType()
							!= Structure.GROUP)
							extendPath(newNode);
						else if (
							((Group) newNode.getUserObject())
								.getOrder()
								.getType()
								!= Order.CHOICE)
							extendPath(newNode);

						if (autoDuplicate) {
							if (element.getStructureType()
								== Structure.ELEMENT) {
								for (int i = 1;
									i < ((ElementDecl) element).getMinOccurs();
									i++) {

									newNode = new XslNode(element);
									parent.add(newNode);

									if (((Annotated) newNode.getUserObject())
										.getStructureType()
										!= Structure.GROUP)
										extendPath(newNode);
									else if (
										((Group) newNode.getUserObject())
											.getOrder()
											.getType()
											!= Order.CHOICE)
										extendPath(newNode);
								}
							}
						}
					}
				}
				check((XslNode) treeModel.getRoot());
				treeModel.reload(parent);
				break;
			case Structure.ELEMENT :
				/* if it's a complex type, look inside */
				XMLType type = ((ElementDecl) annotated).getType();
				if (type.isSimpleType())
					return;
				Enumeration attributes =
					((ComplexType) type).getAttributeDecls();
				while (attributes.hasMoreElements()) {
					node.add(new XslNode((Annotated) attributes.nextElement()));
				}
				Enumeration elements = ((ComplexType) type).enumerate();
				while (elements.hasMoreElements()) {
					Particle ptc = (Particle) elements.nextElement();
					XslNode child = new XslNode((Annotated) ptc);
					node.add(child);
					if (ptc.getStructureType() != Structure.GROUP)
						extendPath(child);
					else if (
						((Group) child.getUserObject()).getOrder().getType()
							!= Order.CHOICE)
						extendPath(child);
				}
				check((XslNode) treeModel.getRoot());
				treeModel.reload(node);
				break;
		}
		node.isExtended = true;
	} // extendPath

	/** 
	* type for references
	* used for going deeper in case 
	* of normalized document
	*/
	protected String refType = "refType";
	protected String refAttribute = "ref";

	/**
	 * List of the types found in the schema that descrobe a reference to an element
	 * 
	 */
	protected ArrayList refTypeList = new ArrayList();

	/**
	 * retrun true if an element of this type is a reference to another element.
	 */
	protected boolean isRefType(String nodeName) {
		return refTypeList.contains(nodeName);
	}

	/**
	 * create a copy of the node and add it to the parent of this node
	 * if the node is not duplicable or if the maximum amount of this 
	 * type of node according to the schema has been reached, do nothing 
	 * @param node the node to duplicate
	 */
	protected void duplicateNode(XslNode node) {
		if (!node.isDuplicable())
			return;
		if (node.max
			== getChildrenCount((XslNode) node.getParent(), node.toString()))
			return;

		//		XslNode child = (XslNode) node.clone();
		XslNode child = node.createBrother();

		XslNode parentNode = (XslNode) node.getParent();
		treeModel.insertNodeInto(child, parentNode, parentNode.getIndex(node));

		/* be sure that this node is not already used */
		child.init();

		if (((Annotated) child.getUserObject()).getStructureType()
			!= Structure.GROUP)
			extendPath(child);
		else if (
			((Group) child.getUserObject()).getOrder().getType()
				!= Order.CHOICE)
			extendPath(child);
	}

	/**
	 * @author arnaud
	 *
	 * The renderer for the tree
	 */
	protected class XslTreeRenderer extends DefaultTreeCellRenderer {
		ImageIcon iconAttribute;
		ImageIcon iconElement;
		Font affected;
		public XslTreeRenderer() {
			iconAttribute = new ImageIcon("images/ic-att.gif");
			iconElement = new ImageIcon("images/ic-elt.gif");
		}

		public Component getTreeCellRendererComponent(
			JTree tree,
			Object value,
			boolean sel,
			boolean expanded,
			boolean leaf,
			int row,
			boolean hasFocus) {

			super.getTreeCellRendererComponent(
				tree,
				value,
				sel,
				expanded,
				leaf,
				row,
				hasFocus);
			XslNode node = (XslNode) value;
			/* set icon and tooltip */
			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.GROUP :
					setIcon(null);
					break;
				case Structure.ATTRIBUTE :
					setIcon(iconAttribute);
					setToolTipText(
						"default value: "
							+ ((AttributeDecl) node.getUserObject())
								.getDefaultValue());
					break;
				case Structure.ELEMENT :
					setIcon(iconElement);
					try {
						setToolTipText(
							(
								(Documentation)
									((Annotation) ((ElementDecl) node
									.getUserObject())
								.getAnnotations()
								.nextElement())
								.getDocumentation()
								.nextElement())
								.getContent());
					} catch (Exception e) {
						setToolTipText("no documentation");
					}

					break;
			}

			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					setText(
						getText()
							+ " ("
							+ ((AttributeDecl) node.getUserObject())
								.getSimpleType()
								.getName()
							+ ")");
					break;
				case Structure.ELEMENT :
					setText(
						getText()
							+ " ("
							+ ((ElementDecl) node.getUserObject())
								.getType()
								.getName()
							+ ")");
			}

			return this;
		}
	}

	/**
	 * describes the node with informations such as its name or its XML type.
	 * Other informations should probably have to be added when extending this class 
	 * @param node the node on which informations are requiered
	 * @return a string describing informations about the node
	 */
	protected String getInfos(XslNode node) {
		String infos = "";

		/* name */
		infos += "name: " + node.toString() + "\n";

		/* XML type */
		infos += "Xml type: ";
		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				infos += "attribute\n\n";
				infos += "This node is ";
				if (!((AttributeDecl) node.getUserObject()).isRequired())
					infos += "not ";
				infos += "requiered\n";
				break;
			case Structure.ELEMENT :
				infos += "element\n";
				infos += "minimum occurences: " + node.min + "\n";
				infos += "maximum occurences: ";
				if (node.max >= 0)
					infos += node.max + "\n";
				else
					infos += "unbounded\n\n";
				infos += "This node is ";
				if (((ElementDecl) node.getUserObject()).getMinOccurs() == 0)
					infos += "not ";
				infos += "requiered\n";
				break;
			default :
				infos += "not XML\n";
		}

		return infos;
	}

	/**
	 * return a understandable <code>String</code> describing the path of a node,
	 * on type: "grandparentNode.ParentNode.Node"
	 * @param path the path to describe
	 * @return an understandable <code>String</code> to describe the node
	 */
	protected String printPath(TreeNode[] path) {
		String value = "";
		for (int i = 0; i < path.length; i++) {
			if (((Annotated) ((XslNode) path[i]).getUserObject())
				.getStructureType()
				!= Structure.GROUP)
				value += "[" + ((XslNode) path[i]).toString() + "]";
		}
		return value;
	}

	/**
	 * a node ca have a value if it is an attribute or if it has a simple content
	 * @param node a node
	 * @return true if the node can have a value
	 */
	protected boolean canHaveValue(XslNode node) {
		if (((Annotated) node.getUserObject()).getStructureType()
			== Structure.ATTRIBUTE)
			return true;

		if (!((ElementDecl) node.getUserObject()).getType().isComplexType())
			return true;

		if (((ElementDecl) node.getUserObject()).getType().getBaseType()
			!= null) {
			if (!((ElementDecl) node.getUserObject())
				.getType()
				.getBaseType()
				.isComplexType())
				return true;
		}
		return false;
	}

	/**
	 * check for errors on this node (lack of associations...) a return an array 
	 * of understandable Strings describing the errors
	 * @param node the node to check
	 * @return an array of Strings describing the errors found
	 */
	protected abstract ArrayList check(XslNode node);

	/**
	 * this class extends DefaultMutableTreeNode for giving it a more 
	 * understandable toString function, 'cuz this function is used for the display of nodes
	 */
	protected class XslNode extends DefaultMutableTreeNode {

		public boolean isExtended = false;
		public boolean isCheckedOk = false;
		public boolean isRequired;
		public boolean isUsed;
		private int use;

		/* keep trace of the parent of this node for choices */
		public XslNode originalParent = null;

		public int min;
		public int max;

		public XslNode createBrother() {
			XslNode brother = new XslNode();
			brother.setUserObject((Annotated) this.getUserObject());

			brother.isRequired = this.isRequired;
			brother.min = this.min;
			brother.max = this.max;
			if (this.originalParent != null) {
				brother.originalParent = this.originalParent.createBrother();
			}
			return brother;
		}

		public boolean isDuplicable() {
			return max > 1 || max == -1;
		}

		public void init() {
			isUsed = false;
			int use = 0;
		}

		private XslNode() {
			super();
		}

		public XslNode(Annotated aValue) {
			super(aValue);
			try {
				if (((AttributeDecl) aValue).isRequired()) {
					isRequired = true;
					min = 1;
				}
				max = 1;
			} catch (ClassCastException e) {
				try {
					if (((Particle) aValue).getMinOccurs() != 0) {
						isRequired = true;
						min = ((Particle) aValue).getMinOccurs();
					}
					max = ((Particle) aValue).getMaxOccurs();

				} catch (ClassCastException e2) {
				}
			}

			try {
				/* ref type */
				if (((ElementDecl) aValue)
					.getType()
					.getName()
					.compareTo(refType)
					== 0
					&& !refTypeList.contains(this.toString())) {
					refTypeList.add(this.toString());
				}
			} catch (Exception e2) {
			}
		}

		public void use() {
			use++;
			if (this.getParent() != null) {
				((XslNode) this.getParent()).use();
			}
			isUsed = true;
		}

		public void useOnlyThis() {
			use();
			//			use++;
			//			isUsed = true;
		}

		public void unuseOnlyThis() {
			unuse();
			//			use--;
			//			isUsed = use > 0;
		}

		public void unuse() {
			use--;
			if (this.getParent() != null) {
				((XslNode) this.getParent()).unuse();
			}
			isUsed = use > 0;
		}

		public String toString() {
			switch (((Annotated) this.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					return ((AttributeDecl) this.getUserObject()).getName();
				case Structure.ELEMENT :
					return ((ElementDecl) this.getUserObject()).getName();
				case Structure.GROUP :
					return choiceToString((Group) this.getUserObject());

				default :
					return ((Annotated) this.getUserObject()).toString();
			}
		}
	}

	/**
	 * transforms a list of choices returned for example by 
	 * the methods <code>getChoices</code> and create a single
	 * <code>String</code> to describe it using for example "|" symbol 
	 * to express a choice between two elements 
	 * @param g a single <code>String</code> to describe a list of choices
	 * @return
	 */
	protected String choiceToString(Group g) {
		Enumeration children = g.enumerate();

		String init;
		String delimiter = "";

		if (g.getOrder().getType() == Order.CHOICE)
			init = " | ";
		else
			init = " & ";

		String value = "(";

		while (children.hasMoreElements()) {
			Annotated child = (Annotated) children.nextElement();
			switch (child.getStructureType()) {
				case Structure.ATTRIBUTE :
					value += delimiter + ((AttributeDecl) child).getName();
					break;
				case Structure.ELEMENT :
					value += delimiter + ((ElementDecl) child).getName();
					break;
				default :
					value += delimiter + choiceToString((Group) child);
			}
			delimiter = init;
		}
		return value + ")";
	}

	protected void displayMessage(String message, String title) {

		JEditorPane editorPane = new JEditorPane();
		editorPane.setEditable(false);
		editorPane.setText(message);
		JScrollPane errorScrollPane = new JScrollPane(editorPane);
		JFrame frame = new JFrame();
		frame.setSize(400, 300);
		frame.getContentPane().add(errorScrollPane);
		frame.show();
	}
}