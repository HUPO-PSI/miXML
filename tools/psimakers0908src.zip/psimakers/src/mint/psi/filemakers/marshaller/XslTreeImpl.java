/*
 * Created on 11 juil. 2003
*/

package mint.psi.filemakers.marshaller;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeNode;

import org.exolab.castor.xml.schema.Annotated;
import org.exolab.castor.xml.schema.Annotation;
import org.exolab.castor.xml.schema.AttributeDecl;
import org.exolab.castor.xml.schema.Documentation;
import org.exolab.castor.xml.schema.ElementDecl;
import org.exolab.castor.xml.schema.Structure;
import org.exolab.castor.xml.schema.XMLType;

/**
 * 
 * This class overides the abstract class AbstractXslTree
 * to provide a tree representation of a XML schema, with 
 * management of marshalling of several flat files to a xml file
 * that respect the schema
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 *
 */
public class XslTreeImpl extends mint.psi.filemakers.xsd.AbstractXsdTree {

	/** file for log messages */
	private File logoutFile;
	private PrintWriter logoutPrintWriter;

	/** id for autogeneration: type MINT-001 */
	private String id = "local";
	/** last id used */
	private int lastId = 0;

	/** text area for warnings and error messages */
	//	JTextArea messagesTextArea = new JTextArea();

	/** keep references between an element and the column in the corresponding tab file */
	private HashMap associatedFields = new HashMap();
	/** keep current values for referenced fields */
	private HashMap associatedFieldsValues = new HashMap();

	/** associate a default value to a node */
	private HashMap associatedValues = new HashMap();
	/** associate a list controlled vocabulary (CV) value to a node */
	private HashMap associatedCV = new HashMap();
	/** associate the number of the controlled vocabulary in 
	 * (i.e. the postition of the definition on a line.) in the CV 
	 * associatedto a node. 
	 */
	private HashMap associatedCVColumn = new HashMap();
	/** list of the nodes for wich the value has to be generated */
	private ArrayList associatedAutogeneration = new ArrayList();
	/** list of the nodes at which are associated each flat file */
	private ArrayList associatedFlatFiles = new ArrayList();

	private FlatFileTabbedPanel flatFileTabbedPanel;
	private FlatFile curFlatFile = null;

	/** lists of controlled vocabularies */
	private CVPanel cvPanel;

	/**
	 * create a new instance of XslTree
	 * The nodes will be automaticaly duplicated
	 * if the schema specify that more than one
	 * element of this type are mandatory 
	 */
	public XslTreeImpl() {
		super(true, true);
	}

	private ButtonGroup associationButtons;
	private JRadioButton fieldAssociation;
	private JRadioButton cvAssociation;
	private JRadioButton defaultAssociation;
	private JRadioButton autoGenerationAssociation;
	private JRadioButton flatFileAssociation;

	/**
	 * create a button panel that includes buttons for loading the schema,
	 * to associate a node to a flat file, a cell a default value or to specify
	 * that a value should be automaticaly generated, to get informations 
	 * about the node, print the XML file or just have a preview of it.
	 */
	protected Box getButtonPanel() {
		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);

		Box treeBox = new Box(BoxLayout.Y_AXIS);
		treeBox.setBorder(new TitledBorder("Schema"));

		Box nodeBox = new Box(BoxLayout.Y_AXIS);
		nodeBox.setBorder(new TitledBorder("Node"));

		Box associationBox = new Box(BoxLayout.Y_AXIS);
		associationBox.setBorder(new TitledBorder("Associations"));

		Box outputBox = new Box(BoxLayout.Y_AXIS);
		outputBox.setBorder(new TitledBorder("Output"));

		/* add a button for loading a XML Schema */
		JButton loadFileb = new JButton("Open a schema");
		loadFileb.setMaximumSize(buttonsDimension);
		loadFileb.addActionListener(new loadSchemaListener());

		JButton setIdb = new JButton("Set your prefix");
		setIdb.setMaximumSize(buttonsDimension);
		setIdb.addActionListener(new setIdListener());

		/* add a button for duplicate a node (in case of lists) */
		JButton duplicateb = new JButton("Duplicate");
		duplicateb.setMaximumSize(buttonsDimension);
		duplicateb.addActionListener(new DuplicateListener());

		JButton infosb = new JButton("About the node");
		infosb.setMaximumSize(buttonsDimension);
		infosb.addActionListener(new infosListener());

		JButton checkb = new JButton("Check");
		checkb.setMaximumSize(buttonsDimension);
		checkb.addActionListener(new checkListener());

		JButton previewb = new JButton("Preview");
		previewb.setMaximumSize(buttonsDimension);
		previewb.addActionListener(new previewListener());

		JButton printb = new JButton("Print");
		printb.setMaximumSize(buttonsDimension);
		printb.addActionListener(new printListener());

		treeBox.add(loadFileb);
		treeBox.add(setIdb);
		treeBox.add(checkb);

		nodeBox.add(duplicateb);
		nodeBox.add(infosb);

		outputBox.add(previewb);
		outputBox.add(printb);

		associationButtons = new ButtonGroup();

		fieldAssociation = new JRadioButton("to field");
		cvAssociation = new JRadioButton("to controlled vocabulary");
		defaultAssociation = new JRadioButton("to default value");
		autoGenerationAssociation = new JRadioButton("to automatic value");
		flatFileAssociation = new JRadioButton("to flat file");

		associationButtons.add(flatFileAssociation);
		associationButtons.add(fieldAssociation);
		associationButtons.add(cvAssociation);
		associationButtons.add(defaultAssociation);
		associationButtons.add(autoGenerationAssociation);
		associationButtons.setSelected(flatFileAssociation.getModel(), true);

		JButton genericAssociationb = new JButton("Associate");
		genericAssociationb.setMaximumSize(buttonsDimension);
		genericAssociationb.addActionListener(new genericAssociationListener());

		JButton genericCancelAssociationb = new JButton("Cancel association");
		genericCancelAssociationb.setMaximumSize(buttonsDimension);
		genericCancelAssociationb.addActionListener(
			new genericCancelAssociationListener());

		associationBox.add(flatFileAssociation);
		associationBox.add(fieldAssociation);
		associationBox.add(cvAssociation);
		associationBox.add(defaultAssociation);
		associationBox.add(autoGenerationAssociation);
		associationBox.add(genericAssociationb);
		associationBox.add(genericCancelAssociationb);

		buttonsPanel.add(treeBox);
		buttonsPanel.add(nodeBox);
		buttonsPanel.add(associationBox);
		buttonsPanel.add(outputBox);

		return buttonsPanel;
	}

	/**
	 * this method should reinitialize every variable makin reference 
	 * to the actual tree, such as any <code>List</code> used to
	 * make associations to externals objects. 
	 * 
	 * reinitializes associations of nodes with columns, default values, 
	 * controlled vocabulries, autogeneration of value and associations to flat files
	 */
	protected void emptySelectionLists() {
		associatedFields = new HashMap();
		associatedValues = new HashMap();
		associatedCV = new HashMap();
		associatedCVColumn = new HashMap();
		associatedAutogeneration = new ArrayList();
		associatedFlatFiles = new ArrayList();
	}

	/**
	 * associate this Panel to a list of controlled vocabularies
	 * @param d a controlled vocabulary
	 */
	public void setCV(CVPanel d) {
		cvPanel = d;
	}

	/**
	 * set the FlatFile in which getting the values
	 * @param f a FlatFile
	 */
	private void setCurrentTabFile(FlatFile f) {
		curFlatFile = f;
	}

	/**
	 * associate this Panel to a FlatFileTabbedPanel
	 * @param d a FlatFileTabbedPanel
	 */
	public void setTabFileTabbedPanel(FlatFileTabbedPanel panel) {
		flatFileTabbedPanel = panel;
	}

	/**
	 * Check if a path is not the subPath of another one
	 * @param path1
	 * @param path2
	 * @return
	 */
	private boolean areSubPaths(TreeNode[] path1, TreeNode[] path2) {
		int minLength;
		if (path1.length < path2.length)
			minLength = path1.length;
		else
			minLength = path2.length;

		for (int i = 0; i < minLength; i++) {
			if (path1[i] != path2[i])
				return true;
		}
		return false;
	}

	/**
	 * Check if the node has a root node for ancestor. It is usefull when associating a node
	 * to a flat file as two root nodes (nodes associated to a flat file) should not have 
	 * children in common
	 * @param node
	 * @return
	 */
	private boolean isChildOfRootPaths(XslNode node) {
		TreeNode[] path = node.getPath();

		for (int i = 0; i < associatedFlatFiles.size(); i++) {
			if (associatedFlatFiles.get(i) != null
				&& !areSubPaths(path,
					((XslNode) associatedFlatFiles.get(i)).getPath()))
				return false;
		}

		return true;
	}

	/**
	 * associate the node selected to the FlatFile selected in the associated FlatFileTabbedPanel.
	 *
	 */
	private void associateFlatFile(XslNode node) {
		XslNode previousAssociation = null;
		/* if the file was already associated, warn the user that all associations to this file will be lost */
		try {
			previousAssociation =
				(XslNode) associatedFlatFiles.get(
					flatFileTabbedPanel.getSelectedIndex());
			if (previousAssociation != null) {
				int confirm =
					JOptionPane.showConfirmDialog(
						new JFrame(),
						"All associations done to this file will be lost. Do you want to continue?",
						"Associatation of a flat file",
						JOptionPane.YES_NO_OPTION);
				if (confirm != JOptionPane.YES_OPTION)
					return;
			}
		} catch (Exception e) {
			/* the file was not yet associated to any node, can go on */
		}

		/* the association has to be done on a node of type element */
		if (((Annotated) (node.getUserObject())).getStructureType()
			!= Structure.ELEMENT) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"the root node should be of type Element",
				"setting a root element",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		try {
			associatedFlatFiles.set(
				flatFileTabbedPanel.getSelectedIndex(),
				null);
		} catch (Exception e) {
			/* ok, no association yet */
		}

		/* the node can not have another rootNode as ancestor */
		if (!isChildOfRootPaths(node)) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"this node is on the pathway of another root node",
				"setting a root element",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		/* remove all associations to this file */
		Iterator keyIterator = associatedFields.keySet().iterator();
		while (keyIterator.hasNext()) {
			Object key = keyIterator.next();
			String value = (String) associatedFields.get(key);
			if (value
				.substring(0, value.indexOf("."))
				.compareTo(
					String.valueOf(flatFileTabbedPanel.getSelectedIndex()))
				== 0) {
				associatedFields.remove(key);
			}
		}

		check((XslNode) treeModel.getRoot());
		if (previousAssociation != null)
			treeModel.reload(previousAssociation);

		for (int i = associatedFlatFiles.size();
			i <= flatFileTabbedPanel.getSelectedIndex();
			i++) {
			associatedFlatFiles.add(null);
		}
		associatedFlatFiles.set(flatFileTabbedPanel.getSelectedIndex(), node);
		/* root node is mandatory */
		rootNode.use();
		flatFileTabbedPanel.setTabTitle(
			flatFileTabbedPanel.getSelectedIndex(),
			node.toString());
	}

	/**
	 * associate a default value to the node selected
	*/
	private void associateDefaultValue(XslNode node) {

		String value =
			(String) JOptionPane.showInputDialog(
				new JFrame(),
				"Enter a default value, \n");

		if (value != null) {
			if (((Annotated) (node.getUserObject())).getStructureType()
				!= Structure.ELEMENT
				&& ((Annotated) (node.getUserObject())).getStructureType()
					!= Structure.ATTRIBUTE) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"a value can only be associated with an node of type element or attribute",
					"associating a value",
					JOptionPane.ERROR_MESSAGE);
				return;

			}

			cancelAllAssociations(node);

			associatedValues.put(node, value);
			// change for ignoring elemts if only default values
			node.useOnlyThis();
			check((XslNode) treeModel.getRoot());
			treeModel.reload(node);
		}
	}

	/**
	 * associate a controlled vocabulary to the node selected.
	 * Each time a value will be requested for this node, 
	 * it will be changed for its controlled vocabulary in target list
	 * if it exists
	 * @param value the value
	 */
	private void associateCV(XslNode node) {

		int cvList = cvPanel.getSelectedCV();

		if (cvList == -1) { // no selection
			displayMessage(
				"No controlled vocabulary selected",
				"[PSI makers: PSI maker]");
			return;
		}

		if (cvPanel.getExampleList().length == 0) { // no selection
			displayMessage(
				"This controlled vocabulary do not contain any value,"
					+ " maybe the separator has not been set properly.",
				"[PSI makers: PSI maker]");
			return;
		}

		AssociateCVListPanel adp = new AssociateCVListPanel();
		int confirm =
			JOptionPane.showConfirmDialog(
				null,
				adp,
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE);

		if (confirm != JOptionPane.OK_OPTION)
			return;

		if (node == null) {
			displayMessage("No node selected", "[PSI makers: PSI maker]");
			return;
		}

		associatedCV.put(node, new Integer(cvList));
		associatedCVColumn.put(node, new Integer(adp.getColumn()));
	}

	private class AssociateCVListPanel extends JPanel {
		int column;
		JList list;
		public int getColumn() {
			return column;
		}

		public AssociateCVListPanel() {
			super();
			setLayout(new BorderLayout());

			list = new JList(cvPanel.getExampleList());
			JScrollPane scrollList = new JScrollPane(list);
			list.addListSelectionListener(new SetColumnlistener());
			add(
				new JLabel("Select the field that contains the definition and press OK:"),
				BorderLayout.NORTH);
			add(scrollList, BorderLayout.CENTER);

		}

		private class SetColumnlistener implements ListSelectionListener {
			public void valueChanged(ListSelectionEvent e) {
				column = list.getSelectedIndex();
			}
		}
	}

	/**
	 * associate the node selected to a cell by its pat representation
	 *
	 */
	private void associateField(XslNode node, String path) {

		/* check if a cell is selected */
		if (path.endsWith("-1")) {
			displayMessage("no cell selected", "[PSI makers: PSI maker]");
			return;
		}

		/* check if a node is selected */
		if (node == null) {
			displayMessage("no node selected", "[PSI makers: PSI maker]");
			return;
		}

		/* check is the file is associated to a node */
		try {
			if (associatedFlatFiles
				.get(Integer.parseInt(path.substring(0, path.indexOf("."))))
				== null) {
				displayMessage(
					"Target flat file is not yet associated to a node.\n "
						+ "You have to associate each file to a node before associating a cell to a node.\n"
						+ "e.g. : associate a file containing on each line the description of an interaction to a node named interactionList.",
					"[PSI makers: PSI maker]");
				return;
			}

			if (!node
				.isNodeAncestor(
					(XslNode) associatedFlatFiles.get(
						Integer.parseInt(
							path.substring(0, path.indexOf(".")))))) {
				displayMessage(
					"Fields from this file have to be descendants from "
						+ ((XslNode) associatedFlatFiles
							.get(
								Integer.parseInt(
									path.substring(0, path.indexOf(".")))))
							.toString(),
					"[PSI makers: PSI maker]");
				return;
			}

		} catch (IndexOutOfBoundsException e) {
			displayMessage(
				"Target flat file is not yet associated to a node. "
					+ "You have to associate each file to a node before associating a cell to a node."
					+ "e.g. : associate a file containing on each line the description of an interaction to a node named interactionList.",
				"[PSI makers: PSI maker]");
			return;
		}

		if (((Annotated) (node.getUserObject())).getStructureType()
			!= Structure.ELEMENT
			&& ((Annotated) (node.getUserObject())).getStructureType()
				!= Structure.ATTRIBUTE) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"a value can only be associated with an node of type element or attribute",
				"associating a value",
				JOptionPane.ERROR_MESSAGE);

			return;
		}

		cancelAllAssociations(node);

		boolean error = false;
		associatedFields.put(node, path);
		node.use();
		check((XslNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/**
	 * removes the association of the node selected with anycontrolled vocabulary
	 */
	private void cancelAssociateCV(XslNode node) {
		associatedCV.remove(node);
		associatedCVColumn.remove(node);
	}

	/**
	 * removes the association of the node selected with a cell
	 */
	private void cancelAssociateField(XslNode node) {
		if (!associatedFields.containsKey(node))
			return;

		associatedFields.remove(node);
		node.unuse();
		check((XslNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/**
	 * removes the association of the node selected with any default value
	 */
	private void cancelDefaultValue(XslNode node) {
		if (!associatedValues.containsKey(node))
			return;

		associatedValues.remove(node);
		node.unuseOnlyThis();
		check((XslNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	/**
	 * checks if the node is associated to a default value
	 * @param node a node
	 * @return true if  such an association exists
	 */
	private boolean hasDefaultValue(XslNode node) {
		return associatedValues.containsKey(node);
	}

	/**
	 * checks if the node is associated to a cell
	 * @param node a node
	 * @return true if  such an association exists
	 */
	private boolean isAffected(XslNode node) {
		return associatedFields.containsKey(node);
	}

	/**
	 * get the value for a node
	 * @param node a node
	 * @return the value in the field associated to this node if the association exists 
	 * (eventually replaced by a controlled vocabulary), if not a automaticaly 
	 * generated value if the node has been setted to request one, if not the default value
	 * if one has been associated to the node. Else return null 
	 */
	private String getValue(XslNode node) {
		/* node affected to a field */
		if (isAffected(node)) {
			String value =
				flatFileTabbedPanel.getValue(
					(String) associatedFields.get(node));

			if (value == null || value.length() == 0) {
				//				try {
				//					logoutPrintWriter.write(
				//						"[file: "
				//							+ curFlatFile.getFileName()
				//							+ " line: "
				//							+ curFlatFile.getLineNumber()
				//							+ "]");
				//				} catch (NullPointerException e) { /* out of a file */
				//					logoutPrintWriter.write("[no file]");
				//				}
				//				logoutPrintWriter.write(
				//					" WARNING: field "
				//						+ ((String) associatedFields.get(node)).substring(
				//							((String) associatedFields.get(node)).indexOf("."))
				//						+ " is empty\n");
				return null;
			}

			if (associatedCV.containsKey(node)) {
				String cvValue =
					cvPanel.getControlledVocabulary(
						((Integer) associatedCV.get(node)).intValue(),
						value,
						((Integer) associatedCVColumn.get(node)).intValue());

				if (cvValue == null || cvValue.length() == 0) {
					//					logoutPrintWriter.write(
					//						" [ERROR] no controlled vocabulary found for value "
					//							+ value
					//							+ " ("
					//							+ cvListPanel.getName(
					//								((Integer) associatedCVList.get(node))
					//									.intValue())
					//							+ ", field "
					//							+ ((String) associatedFields.get(node)).substring(
					//								((String) associatedFields.get(node)).indexOf(
					//									"."))
					//							+ "\n");
					return null;
				}
				return cvValue;
			}
			return value;
		}

		/* node with value autogenerated */
		if (associatedAutogeneration.contains(node)) {
			String value = id + "-" + lastId;
			lastId++;
			return value;
		}

		/* node with default value */
		if (hasDefaultValue(node)) {
			return (String) associatedValues.get(node);
		}
		return null;
	}

	/**
	 * get informations about the node in an understandable String
	 */
	protected String getInfos(XslNode node) {
		if (node == null)
			return "No node selected!";

		String infos = super.getInfos(node);

		infos += ("\nis used: " + node.isUsed + "\n");

		// column associated
		infos += "associated field: " + associatedFields.get(node) + "\n";
		// default value
		infos += "associated value: " + associatedValues.get(node) + "\n";
		// dictionnary
		if (associatedCV.containsKey(node)) {
			infos += "use controlled vocabulary: "
				+ cvPanel.getName(((Integer) associatedCV.get(node)).intValue())+ "\n";
		}
		infos += "automaticaly generate a value: "
			+ associatedAutogeneration.contains(node)
			+ "\n";
		return infos;
	}

	/**
		* check if these are enough associations according to the shema
		* 
		* condition for being  "checkedOK":
		* attributes: if is associated to a value  or not required
		* simpleType elements: if is associated to a value
		* element, complex type: if all sub Elements are checkedOk
		* group: if the count of subElements "checkedOk" is good
		* 
		* condition for errors: elements or group is not "checkedOk"
		*  
		*/
	protected ArrayList check(XslNode node) {

		ArrayList errorMessages = new ArrayList();

		switch (((Annotated) node.getUserObject()).getStructureType()) {

			case Structure.ATTRIBUTE :
				errorMessages = checkAttribute(node);
				break;
			case Structure.ELEMENT :
				errorMessages = checkElement(node);
				break;
			case Structure.GROUP :
				errorMessages = checkGroup(node);
				break;
			default :
				System.out.println(
					"not found type"
						+ ((Annotated) node.getUserObject()).getStructureType());
		}
		return errorMessages;
	}

	private ArrayList checkAttribute(XslNode node) {
		ArrayList errorMessages = new ArrayList();
		if (node.isRequired
			&& !isAffected(node)
			&& !hasDefaultValue(node)
			&& !associatedAutogeneration.contains(node)) {
			errorMessages.add(
				printPath(node.getPath()) + "ERROR: cannot be empty");
			node.isCheckedOk = false;
		} else {
			node.isCheckedOk = true;
		}
		return errorMessages;
	}

	private ArrayList checkElement(XslNode node) {
		ArrayList errorMessages = new ArrayList();

		if (!node.isUsed && !node.isRequired) {
			node.isCheckedOk = true;
			return errorMessages;
		}

		XMLType type = ((ElementDecl) node.getUserObject()).getType();

		/* simpleType */
		if (type.isSimpleType()) {
			if (node.isRequired
				&& !isAffected(node)
				&& !hasDefaultValue(node)
				&& !associatedAutogeneration.contains(node)) {
				errorMessages.add(
					printPath(node.getPath()) + "ERROR: cannot be empty");
				node.isCheckedOk = false;
			} else {
				node.isCheckedOk = true;
			}
		} else { /* complexType, ie: attributes + group */

			boolean errors = false;
			/* check if number of subelts is correct */
			HashMap maxOccurs = new HashMap();
			HashMap minOccurs = new HashMap();

			Enumeration children = node.children();

			while (children.hasMoreElements()) {
				XslNode child = (XslNode) children.nextElement();
				ArrayList subMessages = check(child);

				switch (((Annotated) child.getUserObject())
					.getStructureType()) {
					case Structure.ATTRIBUTE :
						if (subMessages.size() != 0)
							errors = true;
						for (int i = 0; i < subMessages.size(); i++) {
							errorMessages.add(subMessages.get(i));
						}
						break;
					case Structure.GROUP :
						if (subMessages.size() != 0)
							errors = true;
						for (int i = 0; i < subMessages.size(); i++) {
							errorMessages.add(subMessages.get(i));
						}
						break;
					case Structure.ELEMENT :

						/* initialisation if first occurence of the element */
						if (!maxOccurs.containsKey(child.toString())) {
							int max = child.max;
							if (max != -1) {
								maxOccurs.put(
									child.toString(),
									new Integer(max));
							} else {
								maxOccurs.put(child.toString(), "UNBOUNDED");
							}
							minOccurs.put(
								child.toString(),
								new Integer(child.min));
						}

						for (int i = 0; i < subMessages.size(); i++) {
							errorMessages.add(subMessages.get(i));
						}

						if (child.isCheckedOk) {
							try {
								maxOccurs.put(
									child.toString(),
									new Integer(
										((Integer) maxOccurs
											.get(child.toString()))
											.intValue()
											- 1));
							} catch (ClassCastException e) {
								/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
							}
							minOccurs.put(
								child.toString(),
								new Integer(
									((Integer) minOccurs.get(child.toString()))
										.intValue()
										- 1));
						}
				}
			}

			Iterator names = minOccurs.keySet().iterator();

			Iterator mins = minOccurs.values().iterator();
			Iterator maxs = maxOccurs.values().iterator();
			while (names.hasNext()) {
				String name = (String) names.next();
				// if a min is > 0, it means that an element is missing
				if (((Integer) mins.next()).intValue() > 0) {
					errorMessages.add(
						printPath(node.getPath())
							+ "ERROR: a "
							+ name
							+ " is missing");
					errors = true;
				}

				/* if a max is < 0, it means there are too much elements */
				try {
					if (((Integer) maxs.next()).intValue() < 0) {
						errorMessages.add(
							printPath(node.getPath())
								+ " ERROR: a "
								+ name
								+ " should be removed");
						errors = true;
					}

				} catch (ClassCastException e) {
					/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
				}
			}

			node.isCheckedOk = !errors;
		}
		return errorMessages;
	}

	/* 
		* a group can only be a choice (else it would be expanded 
		* if we find it, it means user has to make a choice
		*/
	private ArrayList checkGroup(XslNode node) {
		ArrayList errorMessages = new ArrayList();

		errorMessages.add(
			printPath(node.getPath())
				+ ": WARNING: maybe something is missing.");

		return errorMessages;
	}

	/**
	 * return XML code to close the element
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @return XML code
	 */
	private String closeElement(XslNode node, boolean isEmptyElement) {
		if (isEmptyElement)
			return "";
		return "</" + node.toString() + ">";
	}

	/**
	 * write the XML code to close the element
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @param out the writer used to write the code
	 */
	private void closeElement(XslNode node, boolean isEmptyElement, Writer out)
		throws IOException {
		if (isEmptyElement)
			return;
		out.write("</" + node.toString() + ">");
	}

	/**
	 * write the whole XML file 
	 * @param out the writer used to write the file
	 * @throws IOException
	 */
	public void marshall(Writer out) throws IOException {

		//Create the text area for the status log and configure it.
		//		messagesTextArea = new JTextArea(5, 30);
		//		messagesTextArea.setEditable(false);

		//		JScrollPane scrollPane = new JScrollPane(messagesTextArea);

		marshallNode((XslNode) treeModel.getRoot(), out);

	}

	private class DisplayMessagesListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			try {
				editorPane.setPage(logoutFile.toURL());

				JScrollPane areaScrollPane = new JScrollPane(editorPane);
				areaScrollPane.setVerticalScrollBarPolicy(
					JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				areaScrollPane.setPreferredSize(new Dimension(600, 650));
				JOptionPane.showMessageDialog(new JFrame(), areaScrollPane);
			} catch (IOException ioe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"Documentation not found.",
					"Documentation",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void logoutPrintErrors(XslNode node) {
		if (!node.isRequired)
			return;

		String errorType;
		if (node.isRequired)
			errorType = "[ERROR]";
		else
			errorType = "[WARNING]";

		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				if (!node.isCheckedOk) {
					logoutPrintWriter.write(
						"\n 	"
							+ errorType
							+ " in element "
							+ printPath(node.getPath()));
					logoutPrintWriter.write(
						"\n 	"
							+ errorType
							+ " attribute "
							+ node.toString()
							+ " ignored ("
							+ getNodeProblem(node)
							+ ")");
				}
				break;
			case Structure.ELEMENT :
				//				if (!node.isCheckedOk) {
				XMLType type = ((ElementDecl) node.getUserObject()).getType();
				/* simpleType */
				if (type.isSimpleType()) {
					//					if (node.isUsed && getValue(node) == null) {
					if (!node.isCheckedOk) {
						logoutPrintWriter.write(
							"\n 	"
								+ errorType
								+ " in element "
								+ printPath(node.getPath()));
						logoutPrintWriter.write(
							"\n	"
								+ errorType
								+ " element "
								+ node.toString()
								+ " ignored ("
								+ getNodeProblem(node)
								+ ")");
					}
				} else { /* complex type: go deeper */
					//					if (!node.isCheckedOk) {
					//						if (associatedFlatFiles.contains(node)) {
					//							logoutPrintWriter.write(
					//								"\n 	"
					//									+ errorType
					//									+ " in element ");
					//						}
					//						logoutPrintWriter.write(
					//							"[" + node.toString()  + "]"
					//							);
					//					}
					Enumeration children = node.children();

					while (children.hasMoreElements()) {
						logoutPrintErrors((XslNode) children.nextElement());
					}
				}
				//				}
				break;
			case Structure.GROUP :
				logoutPrintWriter.write(
					"	[WARNING] maybe something is missing in  "
						+ node.toString()
						+ " (you have to click on the node and make a choice).\n");
				break;
			default :
				System.out.println(
					"type not found "
						+ ((Annotated) node.getUserObject()).getStructureType());
				node.isCheckedOk = false;
		}
	}

	/**
	 * write the XML code for a node
	 * @param node the node to marshall  
	 * @param out the writer used to write the file
	 * @throws IOException
	 */
	public void marshall(XslNode node, Writer out) throws IOException {
		lastId = 0;
		marshallNode(node, out);

		/* to reinitialize the display */
		check(node);
	}

	private void marshallAttribute(XslNode node, Writer out)
		throws IOException {

		if (!node.isUsed)
			return;

		if (!node.isCheckedOk && node.isRequired) {
			//			logoutPrintWriter.write(
			//				" [ERROR] attribute "
			//					+ node.toString()
			//					+ " ignored ("
			//					+ getNodeProblem(node)
			//					+ ")\n");
			return;
		}

		String value = getValue(node);

		if (value == null || value.length() == 0) {
			return;
		}

		out.write(
			" "
				+ ((AttributeDecl) node.getUserObject()).getName()
				+ "=\""
				+ value
				+ "\"");
	}

	private void marshallElement(XslNode node, Writer out) throws IOException {
		if (!node.isUsed || !node.isCheckedOk)
			return;

		/* a root node */
		for (int i = 0; i < associatedFlatFiles.size(); i++) {
			if (((XslNode) associatedFlatFiles.get(i)) == node) {
				curFlatFile =
					flatFileTabbedPanel.getTabFileByIndex(
						associatedFlatFiles.indexOf(node));
				marshallFlatFileElement(node, out);
				return;
			}
		}

		ArrayList attributeList = new ArrayList();
		ArrayList elementList = new ArrayList();
		ArrayList groupList = new ArrayList();
		String value = null;

		/*
		 *  get every childs of the node
		 * get the structureType of the userElement 
		 * and use the apropriate marshaller
		 */
		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XslNode child = (XslNode) children.nextElement();

			switch (((Annotated) child.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					attributeList.add(child);
					break;
				case Structure.ELEMENT :
					//					if (!child.isUsed && child.isRequired) {
					//						XMLType type =
					//							((ElementDecl) node.getUserObject()).getType();
					//
					//						/* simpleType */
					//						if (type.isSimpleType()) {
					//							logoutPrintWriter.write(
					//								" [ERROR] element "
					//									+ node.toString()
					//									+ " ignored ("
					//									+ getNodeProblem(node)
					//									+ ")\n");
					//
					//						} else {
					//							logoutPrintWriter.write(
					//								" [ERROR] element "
					//									+ child.toString()
					//									+ " ignored (missing associations)\n");
					//						}
					//					}
					if (child.isUsed)
						elementList.add(child);
					break;
				case Structure.GROUP :
					//					if (!child.isUsed && child.isRequired) {
					//						logoutPrintWriter.write(
					//							"  [WARNING] maybe something is missing in  "
					//								+ child.toString()
					//								+ " (you have to click on the node and make a choice).\n");
					//					}
					if (child.isUsed)
						groupList.add(child);
					break;
			}
		}

		/* get the value affected to this element */
		value = getValue(node);

		boolean isEmptyElement =
			((value == null || value.length() == 0)
				&& elementList.size() == 0
				&& groupList.size() == 0);

		openElement(node, attributeList, isEmptyElement, out);
		if (value != null && value.length() > 0)
			out.write(value);
		for (int i = 0; i < elementList.size(); i++)
			marshallElement((XslNode) elementList.get(i), out);
		for (int i = 0; i < groupList.size(); i++)
			marshallGroup((XslNode) groupList.get(i), out);

		if (elementList.size() != 0 || groupList.size() != 0) {
			out.write("\n");
		}
		closeElement(node, isEmptyElement, out);

	}

	private void marshallGroup(XslNode node, Writer out) throws IOException {

		Enumeration elements = node.children();
		while (elements.hasMoreElements()) {
			marshallNode((XslNode) elements.nextElement(), out);
		}
	}

	private void marshallNode(XslNode node, Writer out) throws IOException {
		if (!node.isUsed || !node.isCheckedOk)
			return;

		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				marshallAttribute(node, out);
				break;
			case Structure.GROUP :
				if (!node.isUsed) {
					//					if (node.isRequired) {
					//						logoutPrintWriter.write(
					//							"  [ERROR] " + node.toString() + " ignored\n");
					//					}
					return;
				}
				marshallGroup(node, out);
				break;
			case Structure.ELEMENT :
				if (!node.isUsed) {
					//					if (node.isRequired) {
					//						logoutPrintWriter.write(
					//							"  [ERROR] "
					//								+ node.toString()
					//								+ " ignored (missing associations)\n");
					//					}
					return;
				}
				marshallElement(node, out);
				break;
			default :
				out.write("<error: unmanaged element/>");
		}
	}

	private void marshallFlatFileElement(XslNode node, Writer out)
		throws IOException {
		ArrayList attributeList = new ArrayList();
		ArrayList elementList = new ArrayList();
		ArrayList groupList = new ArrayList();
		String value = null;

		try {
			logoutPrintWriter.write(
				"\n\n-------------- Marshalling for file:  "
					+ curFlatFile.getFileName()
					+ " --------------------------------------\n");
		} catch (NullPointerException e) { /* out of a file */
			logoutPrintWriter.write(
				"\n\n-------------- no file --------------------------------------\n");
		}

		/* get every childs of the node
		 get the structureType of the userElement 
		 and use the apropriate marshaller
		*/
		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XslNode child = (XslNode) children.nextElement();

			switch (((Annotated) child.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					if (child.isUsed)
						attributeList.add(child);
					break;
				case Structure.ELEMENT :
					if (child.isUsed)
						elementList.add(child);
					break;
				case Structure.GROUP :
					if (child.isUsed)
						groupList.add(child);
					break;
			}
		}

		/* get the value affected to this element */

		value = getValue(node);

		boolean isEmptyElement =
			(value == null && elementList.size() == 0 && groupList.size() == 0);

		openElement(node, attributeList, isEmptyElement, out);
		if (value != null) {
			out.write(value);
		}

		/* for each line */
		boolean endOfFile = false;
		curFlatFile.restartFile();

		/* if the first line contains title, pass througth it */
		if (curFlatFile.firstLineForTitles()) {
			//			try {
			curFlatFile.nextLine();
			//			} catch (IOException e) {
			//				System.out.println("pb: " + e.toString());
			//				endOfFile = true;
			//				curFlatFile.restartFile();
			//			}
		}
		int lineNumber = 0;

		while (!endOfFile) {
			try { /* get each line */

				if (!curFlatFile.hasLine()) {
					System.out.println("no more line");
					throw new IOException("!curFlatFile.hasLine()");
				}
				marshallingCheck(node);

				/* marshall the line */
				for (int i = 0; i < elementList.size(); i++)
					marshallElement((XslNode) elementList.get(i), out);
				for (int i = 0; i < groupList.size(); i++)
					marshallGroup((XslNode) groupList.get(i), out);

				/* get warnings for empty fields and unfound cv */
				String emptyFields = "";
				String unfound = "";
				String unmarshallableElements = "";
				Iterator fieldsIt = associatedFields.keySet().iterator();
				while (fieldsIt.hasNext()) {
					XslNode key = (XslNode) fieldsIt.next();

					String path = ((String) associatedFields.get(key));

					String fieldValue = flatFileTabbedPanel.getValue(path);

					if (key.isNodeAncestor(node)) {
						/* only node that requires fields from current file */
						if (fieldValue == null || fieldValue.length() == 0) {
							emptyFields
								+= path.substring(path.indexOf(".") + 1)
								+ ", ";
							unmarshallableElements += key.toString() + ", ";
						} else {
							if (associatedCV.containsKey(key)) {
								String cvValue =
									cvPanel.getControlledVocabulary(
										((Integer) associatedCV.get(key))
											.intValue(),
										fieldValue,
										((Integer) associatedCVColumn.get(key))
											.intValue());

								if (cvValue == null || cvValue.length() == 0) {
									unfound += fieldValue + ", ";
									unmarshallableElements += key.toString()
										+ ", ";
								}
							}
						}
					}
				}

				if (!node.isCheckedOk
					|| emptyFields.length() > 0
					|| unfound.length() > 0) {
					logoutPrintWriter.write(
						"\n[line " + curFlatFile.getLineNumber() + "]");
					logoutPrintWriter.write(
						"\n	" + curFlatFile.getFieldsIndex());
					logoutPrintWriter.write(
						"\n	" + curFlatFile.getCurLine());
					if (emptyFields.length() > 0) {
						logoutPrintWriter.write(
							"\n	[Warning: empty fields] ");
						logoutPrintWriter.write(emptyFields);
					}
					if (unfound.length() > 0) {
						logoutPrintWriter.write(
							"\n	[Warning: CV] no controlled vocabulary found for: ");
						logoutPrintWriter.write(unfound);
					}
					if (unmarshallableElements.length() > 0) {
						logoutPrintWriter.write(
							"\n	[Warning] following elements will not be marshalled:\n	");
						logoutPrintWriter.write(unmarshallableElements);
					}
					if (!node.isCheckedOk) {
						logoutPrintErrors(node);
						logoutPrintWriter.write(
							"\n[ERROR] line  "
								+ curFlatFile.getLineNumber()
								+ " ignored.");
					}
				}
				check(node);
				curFlatFile.nextLine();
			} catch (IOException e) { /* end of the file */
				endOfFile = true;
				curFlatFile.restartFile();

			} catch (Exception e) {
				endOfFile = true;
				curFlatFile.restartFile();
			}
		}

		if (elementList.size() == 0 && groupList.size() == 0) {
			out.write("\n");
		}

		closeElement(node, isEmptyElement, out);

	}

	/**
	 * write XML code to open the element
	 * @param out the writer used to write the code
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @param attributes a string containing the XML code for the attributes of this element
	 */
	private void openElement(
		XslNode node,
		ArrayList attributes,
		boolean isEmptyElement,
		Writer out)
		throws IOException {
		/* open */
		out.write("\n<" + node.toString());

		/* if root node of the tree */
		if (node == rootNode) {
			out.write(" xmlns=\"" + schema.getTargetNamespace() + "\" ");
			out.write(
				"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ");
		}

		/* attributes */
		for (int i = 0; i < attributes.size(); i++)
			marshallAttribute((XslNode) attributes.get(i), out);

		if (isEmptyElement)
			out.write(" />");
		else
			out.write(">");
	}

	/**
	 * return XML code to open the element
	 * @param node a node
	 * @param isEmptyElement if the node does not have neither attribute nor value or sub elements
	 * @param attributes a string containing the XML code for the attributes of this element
	 * @return the XML code for the element
	 */
	private String openElement(
		XslNode node,
		String attributes,
		boolean isEmptyElement) {
		if (isEmptyElement)
			return "\n<" + node.toString() + attributes + "/>";
		return "\n<" + node.toString() + " " + attributes + ">";
	}

	/**
	 * get a preview of the XML file with only data taken 
	 * from one line in flat files
	 * @return xml code for this preview
	 */
	public String preview() {
		return previewNode((XslNode) treeModel.getRoot());
	}

	public String preview(XslNode node) {
		return previewNode(node);
	}

	private String previewAttribute(XslNode node) {
		String value = getValue(node);

		if (value != null)
			return " "
				+ ((AttributeDecl) node.getUserObject()).getName()
				+ "=\""
				+ value
				+ "\"";
		else
			return null;

	}

	private String previewElement(XslNode node) {

		if (!node.isUsed)
			return null;

		String attributes = "";
		String elements = "";
		String value;
		/* 
		 * get every childs of the node
		 * get the structureType of the userElement 
		 * and use the apropriate marshaller
		*/
		Enumeration children = node.children();
		while (children.hasMoreElements()) {
			XslNode child = (XslNode) children.nextElement();
			switch (((Annotated) child.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					String attribute = previewAttribute(child);
					if (attribute != null)
						attributes += attribute;
					break;
				case Structure.ELEMENT :
					String element = previewElement(child);
					if (element != null)
						elements += element;
					break;
				case Structure.GROUP :
					String group;
					group = previewGroup(child);
					if (group != null)
						elements += group;
					break;
			}
		} /* get the value affected to this element */
		value = getValue(node);

		boolean isEmptyElement = (value == null && elements.length() == 0);
		if (elements.length() != 0)
			elements = elements + "\n";
		if (attributes.length() == 0 && isEmptyElement)
			return null;

		if (value == null)
			value = "";

		return openElement(node, attributes, isEmptyElement)
			+ value
			+ elements
			+ closeElement(node, isEmptyElement);
	}

	private String previewGroup(XslNode node) {

		String group = "";
		Enumeration elements = node.children();
		while (elements.hasMoreElements()) {
			String element = previewNode((XslNode) elements.nextElement());
			if (element != null)
				group += element;
		}
		return group;
	}

	private String previewNode(XslNode node) {
		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				return previewAttribute(node);
			case Structure.GROUP :
				return previewGroup(node);
			case Structure.ELEMENT :
				return previewElement(node);
			default :
				return "<error: unmanaged elementt/>";
		}
	}

	/**
	 * used to displayed in a panel 
	 * an overview of problem found
	 */
	public class checkListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XslNode node = (XslNode) treeModel.getRoot();
			String errors;

			if (node == null) {
				errors = "No schema loaded!";
			} else {
				ArrayList paths = check(node);
				errors = paths.size() + " errors found: \n";
				for (int i = 0; i < paths.size(); i++) {
					errors += paths.get(i) + "\n";
				}
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			editorPane.setText(errors);

			JScrollPane areaScrollPane = new JScrollPane(editorPane);
			areaScrollPane.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			areaScrollPane.setPreferredSize(new Dimension(500, 500));
			JFrame message = new JFrame();
			message.setResizable(true);
//			JOptionPane.showMessageDialog(message, areaScrollPane);
			JFrame frame = new JFrame();
			frame.setSize(400, 300);
			frame.getContentPane().add(areaScrollPane);
			frame.show();

		}
	}

	/**
	 * used to display in a new panel 
	 * informations about the node selected
	 */
	public class infosListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XslNode node = (XslNode) tree.getLastSelectedPathComponent();

			if (node == null) {
				displayMessage("No node selected", "[PSI makers: PSI maker]");
				return;
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			editorPane.setText(getInfos(node));

			JScrollPane scrollPane = new JScrollPane(editorPane);
			scrollPane.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

			JFrame frame = new JFrame();
			frame.setSize(400, 300);
			frame.getContentPane().add(scrollPane);
			frame.show();


//			JOptionPane.showMessageDialog(new JFrame(), scrollPane);
		}
	}

	/** used  for loading the schema */
	public class loadSchemaListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			loadSchema();
		}
	}

	/** used  to duplicate the node selected */
	public class DuplicateListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XslNode node = (XslNode) tree.getLastSelectedPathComponent();
			if (node == null) {
				displayMessage("no node selected", "[PSI makers: PSI maker]");
				return;
			}
			duplicateNode(node);
		}
	}

	private class genericAssociationListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XslNode selectedNode =
				(XslNode) tree.getLastSelectedPathComponent();

			if (selectedNode == null) {
				displayMessage("No node selected", "[PSI makers: PSI maker]");
				return;
			}

			if (flatFileAssociation.isSelected()) {
				associateFlatFile(selectedNode);
				return;
			}

			if (!canHaveValue((XslNode) tree.getLastSelectedPathComponent())) {
				displayMessage(
					"No value can be associated to this node",
					"[PSI makers: PSI maker]");
				return;
			}

			if (fieldAssociation.isSelected()) {
				String path = flatFileTabbedPanel.getSelectedPath();
				associateField(selectedNode, path);
			} else if (cvAssociation.isSelected())
				associateCV(selectedNode);
			else if (defaultAssociation.isSelected())
				associateDefaultValue(selectedNode);
			else if (autoGenerationAssociation.isSelected())
				associateAutoGenerateValue(selectedNode);
		}
	}

	private class genericCancelAssociationListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			XslNode selectedNode =
				(XslNode) tree.getLastSelectedPathComponent();

			if (selectedNode == null) {
				displayMessage("No node selected", "[PSI makers: PSI maker]");
				return;
			}

			if (fieldAssociation.isSelected())
				cancelAssociateField(selectedNode);
			else if (cvAssociation.isSelected())
				cancelAssociateCV(selectedNode);
			else if (defaultAssociation.isSelected())
				cancelDefaultValue(selectedNode);
			else if (autoGenerationAssociation.isSelected())
				cancelAutogenerate(selectedNode);
			else if (flatFileAssociation.isSelected())
				JOptionPane.showMessageDialog(
					new JFrame(),
					"you cannot change association to a flat file",
					"[PSI makers: PSI maker]",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	private void cancelAllAssociations(XslNode node) {
		associatedAutogeneration.remove(node);
		//	associatedDictionnaries.remove(node);
		associatedFields.remove(node);
		associatedValues.remove(node);
	}

	private void associateAutoGenerateValue(XslNode node) {
		cancelAllAssociations(node);
		associatedAutogeneration.add(node);

		node.useOnlyThis();
		check((XslNode) treeModel.getRoot());
		treeModel.reload(node);
	}

	private void cancelAutogenerate(XslNode node) {
		if (!associatedAutogeneration.contains(node))
			return;

		associatedAutogeneration.remove(node);
		node.unuseOnlyThis();
	}

	/** used to display the preview */
	private class previewListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			if (rootNode == null) {
				displayMessage("No schema loaded", "[PSI makers: PSI maker]");
				return;
			}

			JEditorPane editorPane = new JEditorPane();
			editorPane.setEditable(false);
			try {
			editorPane.setText(
				previewNode((XslNode) tree.getLastSelectedPathComponent()));
			} catch (java.lang.NullPointerException noNodeExeption) { /* no node selected */
				editorPane.setText(
					"No preview available.");
			}
			JFrame frame = new JFrame();
			frame.setSize(400, 300);
			frame.getContentPane().add(new JScrollPane(editorPane));
			frame.show();

//			JOptionPane.showMessageDialog(
//				new JFrame(),
//				new JScrollPane(editorPane),
//				"[PSI makers: PSI maker] XML processing for current line",
//				JOptionPane.PLAIN_MESSAGE);
		}
	}

	/**
	 * print a xml output for the whole file
	 */
	private class printListener implements ActionListener {
		JTextField logoutFileName = new JTextField("log.out");
		JFileChooser logFileChooser = new JFileChooser(".");

		public void actionPerformed(ActionEvent e) {

			if (rootNode == null) {
				displayMessage("No schema loaded", "[PSI makers: PSI maker]");
				return;
			}

			TreeNode[] path = rootNode.getPath();
			try {
				JFileChooser fileChooser = new JFileChooser(".");
				JLabel logFileLabel = new JLabel("log file:");
				JButton logoutButton = new JButton("log file");
				logoutButton.addActionListener(new LogoutListener());
				Box logPanel = new Box(BoxLayout.Y_AXIS);
				logPanel.add(logFileLabel);
				logPanel.add(logoutFileName);
				logPanel.add(logoutButton);
				fileChooser.setAccessory(logPanel);

				int confirm = fileChooser.showSaveDialog(new JFrame());

				if (confirm != JOptionPane.OK_OPTION)
					return;

				PrintWriter out =
					new PrintWriter(
						new BufferedWriter(
							new FileWriter(fileChooser.getSelectedFile())));

				if ((logoutFile = logFileChooser.getSelectedFile()) == null) {
					logoutFile = new File(logoutFileName.getText());
					logoutPrintWriter =
						new PrintWriter(
							new BufferedWriter(new FileWriter(logoutFile)));
					logoutFileName.setText(logoutFile.getName());
				}

				out.println("<?xml version=\"1.0\"?>");
				logoutPrintWriter.write(
					"start marshalling to file :"
						+ fileChooser.getSelectedFile().getName()
						+ " at "
						+ new Date()
						+ "\n");
				marshall(out);
				logoutPrintWriter.write(
					"\nmarshalling done, finished at " + new Date() + "\n");

				out.flush();
				out.close();

				logoutPrintWriter.flush();
				logoutPrintWriter.close();

				JPanel panel = new JPanel();
				JButton displayMessages =
					new JButton("Click here to display error messages");
				displayMessages.addActionListener(
					new DisplayMessagesListener());
				panel.add(new JLabel("Marshalling done."));
				panel.add(displayMessages);

				JOptionPane.showMessageDialog(
					new JFrame(),
					panel,
					"[PSI  makers] creating the xml document",
					JOptionPane.ERROR_MESSAGE);

			} catch (FileNotFoundException fe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"PSI-Tab makers",
					JOptionPane.ERROR_MESSAGE);
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"PSI-Tab makers",
					JOptionPane.ERROR_MESSAGE);
			}
		}

		public class LogoutListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				int confirm = logFileChooser.showSaveDialog(new JFrame());
				if (confirm != JOptionPane.OK_OPTION)
					return;
				try {
					/* log file */
					logoutFile = logFileChooser.getSelectedFile();
					logoutPrintWriter =
						new PrintWriter(
							new BufferedWriter(new FileWriter(logoutFile)));
					logoutFileName.setText(logoutFile.getName());
				} catch (FileNotFoundException fe) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"unable to write log file",
						"PSI-Tab makers",
						JOptionPane.ERROR_MESSAGE);
				} catch (IOException ex) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"unable to write log file",
						"PSI-Tab makers",
						JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}

	/**
	 * print a xml output for the whole file
	 */
	private class PrintErrorsListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				JFileChooser fileChooser = new JFileChooser(".");
				int confirm = fileChooser.showSaveDialog(new JFrame());

				if (confirm != JOptionPane.OK_OPTION)
					return;

				PrintWriter out =
					new PrintWriter(
						new BufferedWriter(
							new FileWriter(fileChooser.getSelectedFile())));

				//				out.write(messagesTextArea.getText());

				out.flush();
				out.close();

			} catch (FileNotFoundException fe) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"PSI-Tab makers",
					JOptionPane.ERROR_MESSAGE);
			} catch (IOException ex) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"unable to write file",
					"PSI-Tab makers",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	/** set an id that will be used as prefix for autogenerated values */
	private class setIdListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String s =
				(String) JOptionPane.showInputDialog(
					new JFrame(),
					"Enter a default value, \n");

			if (s != null)
				id = s;
		}
	}

	protected void setCellRenderer() {
		tree.setCellRenderer(new XslTreeRenderer());
	}

	protected class XslTreeRenderer extends DefaultTreeCellRenderer {
		ImageIcon iconAttribute;
		ImageIcon iconElement;

		public XslTreeRenderer() {
			iconAttribute = new ImageIcon("images/ic-att.gif");
			iconElement = new ImageIcon("images/ic-elt.gif");
		}

		public Component getTreeCellRendererComponent(
			JTree tree,
			Object value,
			boolean sel,
			boolean expanded,
			boolean leaf,
			int row,
			boolean hasFocus) {

			super.getTreeCellRendererComponent(
				tree,
				value,
				sel,
				expanded,
				leaf,
				row,
				hasFocus);
			XslNode node = (XslNode) value;
			/* set icon and tooltip */
			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.GROUP :
					setIcon(null);
					break;
				case Structure.ATTRIBUTE :
					setIcon(iconAttribute);
					setToolTipText(
						"default value: "
							+ ((AttributeDecl) node.getUserObject())
								.getDefaultValue());
					break;
				case Structure.ELEMENT :
					setIcon(iconElement);
					try {
						setToolTipText(
							(
								(Documentation)
									((Annotation) ((ElementDecl) node
									.getUserObject())
								.getAnnotations()
								.nextElement())
								.getDocumentation()
								.nextElement())
								.getContent());
					} catch (Exception e) {
						setToolTipText("no documentation");
					}

					break;
			}

			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					setText(
						getText()
							+ " ("
							+ ((AttributeDecl) node.getUserObject())
								.getSimpleType()
								.getName()
							+ ")");
					break;
				case Structure.ELEMENT :
					String type =
						((ElementDecl) node.getUserObject())
							.getType()
							.getName();
					int max = node.max;
					String text = getText() + "(";
					if (type != null)
						text += type + ", ";
					text += "max: ";
					if (max == -1)
						text += "unbounded";
					else
						text += max;
					text += ")";
					setText(text);
			}

			if (isAffected(node)) {
				setText(getText() + ": column " + associatedFields.get(node));
			}

			/* show error */
			setForeground(Color.GRAY);
			if (!node.isCheckedOk && node.isRequired)
				setForeground(Color.RED);

			if (isAffected(node)
				|| hasDefaultValue(node)
				|| associatedAutogeneration.contains(node))
				setForeground(Color.BLACK);

			return this;
		}
	}

	/**
		  * check if these are enough associations according to the shema
		  * 
		  * condition for being  "checkedOK":
		  * attributes: if is associated to a value  or not required
		  * simpleType elements: if is associated to a value
		  * element, complex type: if all sub Elements are checkedOk
		  * group: if the count of subElements "checkedOk" is good
		  * 
		  * condition for errors: elements or group is not "checkedOk"
		  *  
		  */
	protected boolean marshallingCheck(XslNode node) {

		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				return marshallingCheckAttribute(node);
			case Structure.ELEMENT :
				return marshallingCheckElement(node);
			case Structure.GROUP :
				return marshallingCheckGroup(node);
			default :
				System.out.println(
					"not found type"
						+ ((Annotated) node.getUserObject()).getStructureType());
				node.isCheckedOk = false;
				return false;
		}
	}

	private boolean marshallingCheckAttribute(XslNode node) {
		//		if (node.isRequired && getValue(node) == null) {
		if (getValue(node) == null) {
			node.isCheckedOk = false;
			if (node.isRequired)
				return false;
			else
				return true;
		} else {
			node.isCheckedOk = true;
			return true;
		}
	}

	private String getNodeProblem(XslNode node) {
		if (isAffected(node)) {
			String value =
				flatFileTabbedPanel.getValue(
					(String) associatedFields.get(node));

			if (value == null || value.length() == 0) {
				return "the field "
					+ ((String) associatedFields.get(node)).substring(
						((String) associatedFields.get(node)).indexOf(".") + 1)
					+ " is empty";
			}

			if (associatedCV.containsKey(node)) {
				String cvValue =
					cvPanel.getControlledVocabulary(
						((Integer) associatedCV.get(node)).intValue(),
						value,
						((Integer) associatedCVColumn.get(node)).intValue());

				if (cvValue == null || cvValue.length() == 0) {
					return "no controlled vocabulary found for value "
						+ value
						+ " ("
						+ cvPanel.getName(
							((Integer) associatedCV.get(node)).intValue())
						+ ", field "
						+ ((String) associatedFields.get(node)).substring(
							((String) associatedFields.get(node)).indexOf(".")
								+ 1);
				}
			}
		}
		return "no association to this node";
	}

	private boolean marshallingCheckElement(XslNode node) {

		//	  if (!node.isUsed && !node.isRequired) {
		//		  node.isCheckedOk = true;
		//		  return errorMessages;
		//	  }

		XMLType type = ((ElementDecl) node.getUserObject()).getType();

		/* simpleType */
		if (type.isSimpleType()) {
			//			if (node.isRequired && getValue(node) == null) {
			//				//				logoutPrintWriter.write(
			//				//					" ------- missing value for node "
			//				//						+ node.toString()
			//				//						+ " ("
			//				//						+ getNodeProblem(node)
			//				//						+ ")\n");
			//				node.isCheckedOk = false;
			//				return false;
			if (getValue(node) == null) {
				node.isCheckedOk = false;
				if (node.isRequired)
					return false;
				else
					return true;
			} else {
				node.isCheckedOk = true;
				return true;
			}
		} else { /* complexType, ie: attributes + group */

			boolean ok = true;
			/* check if number of subelts is correct */
			HashMap maxOccurs = new HashMap();
			HashMap minOccurs = new HashMap();

			Enumeration children = node.children();

			while (children.hasMoreElements()) {
				XslNode child = (XslNode) children.nextElement();
				marshallingCheck(child);
				boolean childCheckedOk = child.isCheckedOk;

				switch (((Annotated) child.getUserObject())
					.getStructureType()) {
					case Structure.ATTRIBUTE :
						if (!childCheckedOk && child.isRequired) {
							ok = false;
						}
						break;
					case Structure.GROUP :
						//						node.isCheckedOk = false;
						ok = false;
						// should not be groups anymore
						return false;
					case Structure.ELEMENT :

						/* initialisation if first occurence of the element */
						if (!maxOccurs.containsKey(child.toString())) {
							int max = child.max;
							if (max != -1) {
								maxOccurs.put(
									child.toString(),
									new Integer(max));
							} else {
								maxOccurs.put(child.toString(), "UNBOUNDED");
							}
							minOccurs.put(
								child.toString(),
								new Integer(child.min));
						}

						if (childCheckedOk) {
							try {
								maxOccurs.put(
									child.toString(),
									new Integer(
										((Integer) maxOccurs
											.get(child.toString()))
											.intValue()
											- 1));
							} catch (ClassCastException e) {
								/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
							}
							minOccurs.put(
								child.toString(),
								new Integer(
									((Integer) minOccurs.get(child.toString()))
										.intValue()
										- 1));
						}
				}
			}

			Iterator names = minOccurs.keySet().iterator();

			Iterator mins = minOccurs.values().iterator();
			Iterator maxs = maxOccurs.values().iterator();
			while (names.hasNext()) {
				String name = (String) names.next();
				// if a min is > 0, it means that an element is missing
				if (((Integer) mins.next()).intValue() > 0) {
					//					node.isCheckedOk = false;
					ok = false;
					//					return false;
					//					if (node.isRequired)
					//						return false;
					//					else
					//						return true;
				}

				/* if a max is < 0, it means there are too much elements */
				try {
					if (((Integer) maxs.next()).intValue() < 0) {
						ok = false;
						//						node.isCheckedOk = false;
						//						return false;
						//						if (node.isRequired)
						//							return false;
						//						else
						//							return true;
					}

				} catch (ClassCastException e) {
					/* ok, max is unbounded and exception is throws when trying to cast String to Integer */
				}
			}

			//			node.isCheckedOk = true;
			node.isCheckedOk = ok;
			if (node.isRequired && !ok)
				return false;
			else
				return true;
			//			return true;
		}
	}

	/* 
		  * a group can only be a choice (else it would be expanded 
		  * if we find it, it means user has to make a choice
		  */
	private boolean marshallingCheckGroup(XslNode node) {
		ArrayList errorMessages = new ArrayList();
		node.isCheckedOk = false; // should not be group anymore
		return false;
	}

}
