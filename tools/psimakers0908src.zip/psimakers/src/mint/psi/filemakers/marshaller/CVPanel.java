package mint.psi.filemakers.marshaller;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
/**
 * Display a list of the dictionnary and allows to load or select them
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 */
public class CVPanel extends JPanel {

	private DefaultListModel listModel = new DefaultListModel();
	private JList list = new JList(listModel);

	/** dimension for buttons */
	private final Dimension buttonsDimension = new Dimension(160, 25);

	public CVPanel() {
		super(new BorderLayout());

		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);
		buttonsPanel.setBorder(new TitledBorder(""));
		JButton loadDicob = new JButton("Load a CV");
		loadDicob.setMaximumSize(buttonsDimension);
		loadDicob.addActionListener(new loadCVListener());
		buttonsPanel.add(loadDicob);
		JButton editDicob = new JButton("Edit");
		editDicob.setMaximumSize(buttonsDimension);
		editDicob.addActionListener(new editCVListener());
		buttonsPanel.add(editDicob);
		JButton displayDicob = new JButton("Display");
		displayDicob.setMaximumSize(buttonsDimension);
		displayDicob.addActionListener(new displayCVListener());
		buttonsPanel.add(displayDicob);

		list.setFixedCellHeight(10);
		list.setFixedCellWidth(60);
		list.setLayoutOrientation(JList.VERTICAL);
		list.setAutoscrolls(true);
		list.setVisible(true);

		JScrollPane scrollList = new JScrollPane(list);
		add(scrollList, BorderLayout.CENTER);
		add(buttonsPanel, BorderLayout.SOUTH);

	}

	/**
	 * returns the definition associated to a word in target dictionnary
	 * @param dico the dictionnary in which to look
	 * @param value the value to search
	 * @param definitionNumber the number of the definition to look for, as a value 
	 * can have more than one definition, i.e. the postition of the definition on a line.
	 * @return the definition
	 */
	public String getControlledVocabulary(int dico, String value, int definitionNumber) {
		return ((ControlledVocabulary) listModel.elementAt(dico)).getDefinition(
			value,
			definitionNumber);
	}

	/**
	 * index of the dictionnary delected in the list
	 * @return index of the dictionnary curently selected
	 * on the list
	 */
	public int getSelectedCV() {
		return list.getSelectedIndex();
	}

	public String[] getExampleList() {
		return ((ControlledVocabulary) listModel.elementAt(list.getSelectedIndex()))
			.exampleList();
	}

	/**
	 * the name of a dictionnary in the list
	 * @param dico index of the dictionnary in the list
	 * @return the name of the dictionnary selected on the list
	 */
	public String getName(int index) {
		return ((ControlledVocabulary) listModel.elementAt(index)).toString();
	}

	/**
	 * use to load a new dictionnary and add it to the list
	 */
	private class loadCVListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			loadDico();
		}
	}

	/**
	 * use to remove a dictionnary and add it to the list
	 */
	private class removeCVListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			removeDico();
		}
	}

	/**
	 * use to remove a dictionnary and add it to the list
	 */
	private class editCVListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			editCV();
		}
	}

	/**
	 * display a line from the dictionnary
	 */
	private class displayCVListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			displayCV();
		}
	}

	/**
	 * Load a dictionnary. The dictionnary is load from a file specified in 
	 * an OptionPanel
	 */
	private void loadDico() {
		JTextField separator = new JTextField();
		JTextField fileName = new JTextField();
		JCheckBox caseSensitive = new JCheckBox();

		try {
			Box panel = new Box(BoxLayout.Y_AXIS);

			JFileChooser fc = new JFileChooser(".");

			panel.add(new JLabel("Separator"));
			panel.add(separator);
			panel.add(new JLabel("Case sensitive"));
			panel.add(caseSensitive);
			fc.setAccessory(panel);

			int returnVal = fc.showOpenDialog(new JFrame());
			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			ControlledVocabulary dico = new ControlledVocabulary(
			fc.getSelectedFile(),
			separator.getText(),
			caseSensitive.isSelected());
			if (dico != null)	listModel.addElement(dico);

		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException npe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Load a dictionnary. The dictionnary is load from a file specified in 
	 * an OptionPanel
	 */
	private void removeDico() {
		JTextField separator = new JTextField();
		JTextField fileName = new JTextField();
		JCheckBox caseSensitive = new JCheckBox();

		if (list.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"No dictionnary selected",
				"[PSI makers: PSI maker]",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		/* ask for confirmation */
		int confirm =
			JOptionPane.showConfirmDialog(
				new JFrame(),
				"All associations done to this dictionnary will be lost. Do you want to continue?",
				"Associatation of a dictionnary",
				JOptionPane.YES_NO_OPTION);
		if (confirm != JOptionPane.YES_OPTION) {
			return;
		}

		listModel.setElementAt("empty", list.getSelectedIndex());
	}

	/**
	 * Load a dictionnary. The dictionnary is load from a file specified in 
	 * an OptionPanel
	 */
	private void editCV() {

		if (list.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"No dictionnary selected",
				"[PSI makers: PSI maker]",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		ControlledVocabulary curentDictionnary = (ControlledVocabulary) list.getSelectedValue();
		JTextField separator = new JTextField(curentDictionnary.getSeparator());
		JTextField fileName =
			new JTextField(curentDictionnary.getFile().getName());
		JCheckBox caseSensitive = new JCheckBox();
		caseSensitive.setSelected(curentDictionnary.isCaseSensitive());

		try {
			Box panel = new Box(BoxLayout.Y_AXIS);

			JFileChooser fc = new JFileChooser(".");
			fc.setSelectedFile(curentDictionnary.getFile());
			panel.add(new JLabel("Separator"));
			panel.add(separator);
			panel.add(new JLabel("Case sensitive"));
			panel.add(caseSensitive);
			fc.setAccessory(panel);

			int returnVal = fc.showOpenDialog(new JFrame());
			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			listModel.setElementAt(
				new ControlledVocabulary(
					fc.getSelectedFile(),
					separator.getText(),
					caseSensitive.isSelected()),
				list.getSelectedIndex());

		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException npe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	private void displayCV() {
		if (list.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"No dictionnary selected",
				"[PSI makers: PSI maker]",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		JList exampleList =
			new JList(((ControlledVocabulary) list.getSelectedValue()).exampleList());
		JScrollPane scrollList = new JScrollPane(exampleList);
		JOptionPane.showMessageDialog(
			new JFrame(),
			scrollList,
			"[PSI makers: dictionnary] "
				+ ((ControlledVocabulary) list.getSelectedValue()).getFile().getName(),
			JOptionPane.ERROR_MESSAGE);

	}

}