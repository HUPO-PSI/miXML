#!/bin/csh


java -classpath bin/psimakers.jar:libs/xercesImpl.jar:libs/castor-0.9.5-xml.jar:libs/xml-apis.jar:libs/xmlParserAPIs.jar mint.psi.filemakers.marshaller.Marshaller
