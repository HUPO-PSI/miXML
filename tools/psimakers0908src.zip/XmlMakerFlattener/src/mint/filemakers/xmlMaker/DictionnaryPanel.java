package mint.filemakers.xmlMaker;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
/**
 * Display a list of the dictionnary and allows to load or select them
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 */
public class DictionnaryPanel extends JPanel {

	private DefaultListModel listModel = new DefaultListModel();
	private JList list = new JList(listModel);

	/** dimension for buttons */
	private final Dimension buttonsDimension = new Dimension(180, 25);

	public DictionnaryPanel() {
		super(new BorderLayout());

		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);
		buttonsPanel.setBorder(new TitledBorder(""));
		JButton loadDicob = new JButton("Load a dictionnary");
		loadDicob.setMaximumSize(buttonsDimension);
		loadDicob.addActionListener(new loadDictionnaryListener());
		buttonsPanel.add(loadDicob);
		JButton editDicob = new JButton("Change the dictionnary");
		editDicob.setMaximumSize(buttonsDimension);
		editDicob.addActionListener(new editDictionnaryListener());
		buttonsPanel.add(editDicob);
		JButton displayDicob = new JButton("Display a Line");
		displayDicob.setMaximumSize(buttonsDimension);
		displayDicob.addActionListener(new displayALineListener());
		buttonsPanel.add(displayDicob);

		list.setFixedCellHeight(10);
		list.setFixedCellWidth(60);
		list.setLayoutOrientation(JList.VERTICAL);
		list.setAutoscrolls(true);
		list.setVisible(true);

		listModel.removeAllElements();
		JScrollPane scrollList = new JScrollPane(list);
		add(scrollList, BorderLayout.CENTER);
		add(buttonsPanel, BorderLayout.SOUTH);
	}

	/**
	 * returns the definition associated to a word in target dictionnary
	 * @param dico the dictionnary in which to look
	 * @param value the value to search
	 * @param definitionNumber the number of the definition to look for, as a value 
	 * can have more than one definition, i.e. the postition of the definition on a line.
	 * @return the definition
	 */
	public String getReplacementValue(
		int dico,
		String value,
		int definitionNumber) {
		return ((Dictionnary) listModel.elementAt(dico)).getDefinition(
			value,
			definitionNumber);
	}

	/**
	 * index of the dictionnary delected in the list
	 * @return index of the dictionnary curently selected
	 * on the list
	 */
	public int getSelectedDictionnary() {
		return list.getSelectedIndex();
	}

	public String[] getExampleList() {
		return ((Dictionnary) listModel.elementAt(list.getSelectedIndex()))
			.exampleList();
	}

	/**
	 * the name of a dictionnary in the list
	 * @param dico index of the dictionnary in the list
	 * @return the name of the dictionnary selected on the list
	 */
	public String getName(int index) {
		return ((Dictionnary) listModel.elementAt(index)).toString();
	}

	/**
	 * use to load a new dictionnary and add it to the list
	 */
	private class loadDictionnaryListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			loadDictionnary();
		}
	}

	/**
	 * use to remove a dictionnary and add it to the list
	 */
	private class removeDictionnaryListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			removeDictionnary();
		}
	}

	/**
	 * use to remove a dictionnary and add it to the list
	 */
	private class editDictionnaryListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			editDictionnary();
		}
	}

	/**
	 * display a line from the dictionnary
	 */
	private class displayALineListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			displayALine();
		}
	}

	/**
	 * Load a dictionnary. The dictionnary is load from a file specified in 
	 * an OptionPanel
	 */
	private void loadDictionnary() {
		JTextField separator = new JTextField();
		JTextField fileName = new JTextField();
		JCheckBox caseSensitive = new JCheckBox();

		try {
			Box panel = new Box(BoxLayout.Y_AXIS);

			JFileChooser fc = new JFileChooser(".");

			panel.add(new JLabel("Separator"));
			panel.add(separator);
			panel.add(new JLabel("Case sensitive"));
			panel.add(caseSensitive);
			fc.setAccessory(panel);

			int returnVal = fc.showOpenDialog(new JFrame());
			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			Dictionnary dico =
				new Dictionnary(
					fc.getSelectedFile(),
					separator.getText(),
					caseSensitive.isSelected());
			if (dico != null)
				listModel.addElement(dico);

		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException npe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Load a dictionnary. The dictionnary is load from a file specified in 
	 * an OptionPanel
	 */
	private void removeDictionnary() {
		JTextField separator = new JTextField();
		JTextField fileName = new JTextField();
		JCheckBox caseSensitive = new JCheckBox();

		if (list.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"No dictionnary selected",
				"[PSI makers: PSI maker]",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		/* ask for confirmation */
		int confirm =
			JOptionPane.showConfirmDialog(
				new JFrame(),
				"All associations done to this dictionnary will be lost. Do you want to continue?",
				"Associatation of a dictionnary",
				JOptionPane.YES_NO_OPTION);
		if (confirm != JOptionPane.YES_OPTION) {
			return;
		}

		listModel.setElementAt("empty", list.getSelectedIndex());
	}

	/**
	 * Load a dictionnary. The dictionnary is load from a file specified in 
	 * an OptionPanel
	 */
	private void editDictionnary() {

		if (list.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"No dictionnary selected",
				"[PSI makers: PSI maker]",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		Dictionnary curentDictionnary = (Dictionnary) list.getSelectedValue();
		JTextField separator = new JTextField(curentDictionnary.getSeparator());
		JTextField fileName =
			new JTextField(curentDictionnary.getFile().getName());
		JCheckBox caseSensitive = new JCheckBox();
		caseSensitive.setSelected(curentDictionnary.isCaseSensitive());

		try {
			Box panel = new Box(BoxLayout.Y_AXIS);

			JFileChooser fc = new JFileChooser(".");
			fc.setSelectedFile(curentDictionnary.getFile());
			panel.add(new JLabel("Separator"));
			panel.add(separator);
			panel.add(new JLabel("Case sensitive"));
			panel.add(caseSensitive);
			fc.setAccessory(panel);

			int returnVal = fc.showOpenDialog(new JFrame());
			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			listModel.setElementAt(
				new Dictionnary(
					fc.getSelectedFile(),
					separator.getText(),
					caseSensitive.isSelected()),
				list.getSelectedIndex());

		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException npe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] load dictionnary",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Display in a new frame a list of the data found in the line with the most elements
	 *
	 */
	private void displayALine() {
		if (list.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"No dictionnary selected",
				"[PSI makers: PSI maker]",
				JOptionPane.ERROR_MESSAGE);
			return;
		}

		String exampleLine =
			((Dictionnary) list.getSelectedValue()).exampleLine();
		String separator =
			((Dictionnary) list.getSelectedValue()).getSeparator();

		JList exampleList =
			//			new JList(
		//				((ControlledVocabulary) list.getSelectedValue()).exampleList());
	new JList(exampleLine.split(separator));

		JScrollPane scrollList = new JScrollPane(exampleList);

		JFrame frame = new JFrame();
		Box box = new Box(BoxLayout.Y_AXIS);
		box.add(new JLabel("example line: " + exampleLine));
		box.add(new JLabel("separator: " + separator));
		box.add(scrollList);
		frame.getContentPane().add(box);
		frame.setTitle("dictionnary: " + list.getSelectedValue());
		frame.setSize(600, 300);
		frame.show();
	}

	public void save(ObjectOutputStream oos) {
		try {
			int nbDictionnaries = listModel.getSize();
			oos.writeInt(nbDictionnaries);

			for (int i = 0; i < nbDictionnaries; i++) {
				//
				oos.writeBoolean(
					((Dictionnary) listModel.getElementAt(i))
						.isCaseSensitive());
				oos.writeObject(
					((Dictionnary) listModel.getElementAt(i)).getSeparator());
				oos.writeObject(
					((Dictionnary) listModel.getElementAt(i))
						.getFile()
						.getPath());
				//
				//				((Dictionnary) listModel.getElementAt(i)).save(oos); 
			}
		} catch (IOException e) {
			System.out.println("failed to save");
		}
	}

	public void load(ObjectInputStream ois) {
		try {
			listModel.removeAllElements();
			int nbDictionnaries = ois.readInt();
			for (int i = 0; i < nbDictionnaries; i++) {

				boolean caseSensitive = ois.readBoolean();
				String separator = (String) ois.readObject();
				String filePath = (String) ois.readObject();
				Dictionnary dico;
				try {
					 dico =
						new Dictionnary(
							new File(filePath),
							separator,
							caseSensitive);
					listModel.addElement(dico);
				} catch (Exception ioe) {
					String fileName;
					if (filePath.lastIndexOf("/") >= 0)
						fileName =
							filePath.substring(filePath.lastIndexOf("/") + 1);
					else if (filePath.lastIndexOf("\\") >= 0)
						fileName =
							filePath.substring(filePath.lastIndexOf("\\") + 1);
					else
						fileName = filePath;

					JOptionPane.showMessageDialog(
							new JFrame(),
							"File not found: " + fileName,
							"[PSI makers]",
							JOptionPane.ERROR_MESSAGE);

					JEditorPane panel = new JEditorPane();
					panel.setEditable(false);
					panel.setText("file '" + fileName + "' not found:");
					JFileChooser fileChooser = new JFileChooser(".");
					fileChooser.setAccessory(panel);
					fileChooser.setDialogTitle(filePath + "not found");

					int returnVal = fileChooser.showOpenDialog(this);
					if (returnVal != JFileChooser.APPROVE_OPTION) {
						return;
					}	 
					dico =new Dictionnary(
						fileChooser.getSelectedFile(),
						separator,
						caseSensitive);
					listModel.addElement(dico);
				}
			}
		} catch (IOException e) {
			System.out.println("failed to load dictionnaries.");
		} catch (ClassNotFoundException e) {
			System.out.println("failed to load dictionnary: file");
		}
	}
}