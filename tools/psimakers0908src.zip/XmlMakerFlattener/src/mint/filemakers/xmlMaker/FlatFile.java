package mint.filemakers.xmlMaker;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 * The class provide graphical management for a tab delimited file <br>
 * It allows to load a file, choose the field delimitor, and recursively 
 * enter into the fields and split them.
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 */
public class FlatFile extends JPanel {

	/** true if first line of the file contains titles and should not be parse */
	private boolean titleLine = false;

	/** dimension for buttons */
	private final Dimension buttonsDimension = new Dimension(180, 25);

	/** main list */
	private FlatList rootList;

	/** current line */
	private String line;

	/** current line number */
	private int lineNumber = 0;

	/** 
	 * part of previous line that has not been readed
	 * used when the line separator is not the end of the line
	 */
	private String restOfPreviousLine = new String();

	private boolean endOfFile = true;

	/** 
	 * line separator: if null, lines will be readed one by one in the file
	 * else the readline function will read the file untill it find the separator
	 */
	private String lineSeparator = null;

	/**
	 * set current line in this Object and recursively in all lists
	 */
	private void setLine(String aLine) {
		line = aLine;
		rootList.setLine(line);
	}

	/**
	 * get down across the lists following the path to find corresponding value
	 */
	public String getValue(String path) {
		return rootList.getValue(path);
	}

	/** the flat file */
	private File f;
	private BufferedReader reader;

	/**
	 * initialise the reader and the file
	 */
	private void reload() {
		try {
			lineNumber = 0;
			reader = new BufferedReader(new FileReader(f));
		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file",
				"[PSI makers: PSI maker] Flat File",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * load a flat file. The file is choosed 
	 * by the user in an option panel
	 */
	private void loadFile() {
		JTextField separator = new JTextField();
		JTextField fileName = new JTextField();
		JCheckBox forgetFirstLine = new JCheckBox();
		try {
			lineNumber = 0;
			Box panel = new Box(BoxLayout.Y_AXIS);

			JFileChooser fc = new JFileChooser(".");

			panel.add(new JLabel("Line separator"));
			panel.add(separator);
			panel.add(new JLabel("first line for titles (do not parse it)"));
			panel.add(forgetFirstLine);
			fc.setAccessory(panel);

			int returnVal = fc.showOpenDialog(new JFrame());
			if (returnVal != JFileChooser.APPROVE_OPTION) {
				return;
			}

			f = fc.getSelectedFile();
			reader = new BufferedReader(new FileReader(f));

			if (f == null)
				return;

			if (separator.getText().length() != 0) {
				lineSeparator = separator.getText();
			} else {
				lineSeparator = null;
			}

			titleLine = forgetFirstLine.isSelected();
			nextLine();
			//			rootList.setLine(line);
		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load the file",
				"[PSI makers: PSI maker] Flat File",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException ioe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load the file",
				"[PSI makers: PSI maker] Flat File",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * load a flat file. The file is choosed 
	 * by the user in an option panel
	 */
	private void loadFile(File file) {
		try {
			lineNumber = 0;
			Box panel = new Box(BoxLayout.Y_AXIS);

			reader = new BufferedReader(new FileReader(file));

			//			if (file == null)
			//				return;

			f = file;
			nextLine();
			//			rootList.setLine(line);
		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load the file",
				"[PSI makers: PSI maker] Flat File",
				JOptionPane.ERROR_MESSAGE);
		} catch (NullPointerException ioe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load the file",
				"[PSI makers: PSI maker] Flat File",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/** 
	 * try to read a new line
	 */
	public void nextLine() {
		if (f == null) {
			endOfFile = true;
			return;
		}

		if (lineSeparator == null) {
			try {
				String newLine = reader.readLine();
				if (newLine != null) {
					setLine(newLine);
					endOfFile = false;
					lineNumber++;
				} else {
					endOfFile = true;
				}
			} catch (IOException e) {
				System.out.println("nextline pb: " + e.toString());
				endOfFile = true;
			}
		} else /* read until lineSeparator is found */ {
			String line = restOfPreviousLine;
			StringBuffer newLine = new StringBuffer();
			try {
				while (line.indexOf(lineSeparator) < 0) {
					newLine.append(line);
					line = reader.readLine();
					lineNumber++;
				}
				newLine.append(line.substring(0, line.indexOf(lineSeparator)));
				restOfPreviousLine =
					line.substring(
						line.indexOf(lineSeparator) + lineSeparator.length());

				if (newLine != null) {
					setLine(newLine.toString());
					endOfFile = false;
				} else {
					endOfFile = true;
				}

			} catch (IOException e) {
				if (newLine.length() != 0) {
					setLine(newLine.toString());
					endOfFile = true;
				} else {
					endOfFile = true;
				}
			}
		}
	}

	/** 
	 * try to read a new line until one with selected field not empty is found
	 */
	public void nextLineWithField() {
		if (f == null)
			return;

		nextLine();

		while (hasLine()
			&& (list.getSelectedValue() == null
				|| list.getSelectedValue().length() == 0)) {
			nextLine();
		}
	}

	/**
	 * @return true if a line has been readed
	 */
	public boolean hasLine() {
		//		return line != null;
		return !endOfFile;
	}

	/**
	 * go back to the beginning of the file
	 */
	public void restartFile() {
		reload();
		nextLine();
	}

	private DefaultListModel listModel = new DefaultListModel();

	/** current and displayed list */
	private FlatList list = new FlatList(null, null);

	public FlatFile() {
		super(new BorderLayout());

		rootList = list;

		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);
		Box buttonsPanelTop = new Box(BoxLayout.Y_AXIS);

		Box nextLineBox = new Box(BoxLayout.Y_AXIS);
		nextLineBox.setBorder(new TitledBorder(""));
		Box cellBox = new Box(BoxLayout.Y_AXIS);
		cellBox.setBorder(new TitledBorder(""));

		JButton fileb = new JButton("Open a file");
		fileb.setMaximumSize(buttonsDimension);
		fileb.addActionListener(new loadFileListener());

		buttonsPanelTop.add(fileb);

		JButton nextLineb = new JButton("To next line");
		nextLineb.setMaximumSize(buttonsDimension);
		nextLineb.addActionListener(new nextLineListener());

		nextLineBox.add(nextLineb);

		JButton nextLineWithFieldb = new JButton("To next value");
		nextLineWithFieldb.setMaximumSize(buttonsDimension);
		nextLineWithFieldb.addActionListener(new nextLineWithFieldListener());

		nextLineBox.add(nextLineWithFieldb);

		JButton firstLineb = new JButton("Back to first line");
		firstLineb.setMaximumSize(buttonsDimension);
		firstLineb.addActionListener(new firstLineListener());

		nextLineBox.add(firstLineb);

		JButton enterb = new JButton("Split Cell");
		enterb.setMaximumSize(buttonsDimension);
		enterb.addActionListener(new enterListener());

		cellBox.add(enterb);

		JButton backb = new JButton("Back to parent list");
		backb.setMaximumSize(buttonsDimension);
		backb.addActionListener(new backListener());

		cellBox.add(backb);

		buttonsPanel.add(cellBox);
		buttonsPanel.add(nextLineBox);

		add(buttonsPanelTop, BorderLayout.NORTH);
		add(list, BorderLayout.CENTER);
		add(buttonsPanel, BorderLayout.SOUTH);
	}

	/** 
	 * used for loading a file
	 */
	private class loadFileListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			loadFile();
		}
	}

	/**
	 * used for reading a new line and update the lists
	 */
	private class nextLineListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			nextLine();
			if (!hasLine()) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"No more line to read",
					"[PSI makers: PSI maker] Flat File",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private class nextLineWithFieldListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			nextLineWithField();
			if (!hasLine()) {
				JOptionPane.showMessageDialog(
					new JFrame(),
					"No more line to read",
					"[PSI makers: PSI maker] Flat File",
					JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	/**
	 * used for reloading the file and display the first line and update the lists
	 */
	private class firstLineListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			reload();
			nextLine();
			rootList.setLine(line);
		}
	}

	/**
	 * used to set the line separator 
	 */
	private class setLineSeparatorListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String s =
				(String) JOptionPane.showInputDialog(
					new JFrame("[PSI makers: PSI maker] Flat File"),
					"Line Separator (use regular expression, e.g.: // \n",
					"//");

			if (s != null)
				lineSeparator = s;
		}
	}

	/**
	 * used to create a new list with selected cell 
	 */
	private class enterListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			FlatList newList = null;
			try {
				newList = list.getChildList();
			} catch (NullPointerException ex) {
				return;
			}
			if (newList != null) {
				list.setVisible(false);
				list = newList;
				list.setVisible(true);
				add(list, BorderLayout.CENTER);
				list.setVisible(true);
			}
		}
	}

	/**
	 * use to go back to parent cell
	 */
	private class backListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (list != rootList) {
				list.setVisible(false);
				list = list.getParentList();
				add(list, BorderLayout.CENTER);
				list.setVisible(true);
			}
		}
	}

	/**
	 * @return the path describing current cell
	 * e.g. : for the second cell from created with third cell of the main list: 3.2
	 */
	public String getSelectedPath() {
		return list.getSelectedPath();
	}

	/**
	 * Return true if the first line of the file is used for titles. 
	 * Used to know wether or not to parse the first line.
	 * @return true if the first line of the file is used for titles
	 */
	public boolean firstLineForTitles() {
		return titleLine;
	}

	/**
	 * Get the name of the file associated.
	 * @return
	 */
	public String getFileName() {
		return f.getName();
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public String getFieldsIndex() {
		return rootList.getFieldsIndex();
	}

	public String getCurLine() {
		return line;
	}

	public void save(ObjectOutputStream oos) {
		try {
			oos.writeBoolean(titleLine);
			oos.writeObject(lineSeparator);
			if (f != null) {
				oos.writeObject(f.getPath());
				rootList.save(oos);
			} else {
				oos.writeObject(null);
			}
		} catch (IOException e) {
			System.out.println("failed to save");
		}
	}

	public void load(ObjectInputStream ois) {
		try {
			titleLine = ois.readBoolean();
			lineSeparator = (String) ois.readObject();
			/** TODO: if file not found -> open a filechooser */
			String filePath = (String) ois.readObject();
			if (filePath != null) {
				try {
					loadFile(new File(filePath));
					rootList.load(ois); 
					reload();
					nextLine();
				} catch (Exception ioe) {
					String fileName;
					if (filePath.lastIndexOf("/") >= 0)
						fileName =
							filePath.substring(filePath.lastIndexOf("/") + 1);
					else if (filePath.lastIndexOf("\\") >= 0)
						fileName =
							filePath.substring(filePath.lastIndexOf("\\") + 1);
					else
						fileName = filePath;

					JOptionPane.showMessageDialog(
							new JFrame(),
							"File not found: " + fileName,
							"[PSI makers]",
							JOptionPane.ERROR_MESSAGE);


					JEditorPane panel = new JEditorPane();
					panel.setEditable(false);
					panel.setText("file '" + fileName + "' not found:");
					JFileChooser fileChooser = new JFileChooser(".");
					fileChooser.setAccessory(panel);
					fileChooser.setDialogTitle(filePath + "not found");

					int returnVal = fileChooser.showOpenDialog(this);
					if (returnVal != JFileChooser.APPROVE_OPTION) {
						return;
					}
					loadFile(fileChooser.getSelectedFile());
					rootList.load(ois);
					reload();
					nextLine();
				}
			}
		} catch (IOException e) {
			System.out.println("failed to load");
		} catch (ClassNotFoundException e) {
			System.out.println("failed to load");
		}
	}

}
