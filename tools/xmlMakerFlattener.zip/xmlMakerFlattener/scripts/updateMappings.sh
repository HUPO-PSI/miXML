#/bin/sh
perl -pi -e 's/class\=\"mint\./class\=\"psidev\.psi\.mi\./g' $1
